import { PRODUCT_NAME, PRODUCT_VERSION, COMPANY_NAME } from './productName';

export const APP_CONFIG = {
  STORE_NAME: `${PRODUCT_NAME} Bespoke Tailoring`,
  VERSION: PRODUCT_VERSION,
  COMPANY_NAME,
  CONTACT_WHATSAPP: '+919876543210',
  CONTACT_PHONE: '+919876543210',
  CONTACT_EMAIL: 'support@marcosbespoke.com',
};
