import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Platform
} from 'react-native';
import { useTheme } from '../../styles/ThemeContext';
import { APP_CONFIG } from '../../config/app.config';
import { ChevronLeft, Shield, Lock, Eye, Baby, Trash2, Cpu, FileCheck, Mail, PhoneCall, Key } from 'lucide-react-native';

export default function PrivacyPolicyScreen({ navigation }) {
  const { theme, fonts, shadows } = useTheme();

  const storeName = APP_CONFIG.STORE_NAME || 'MARCOS Bespoke Tailoring';
  const contactPhone = APP_CONFIG.CONTACT_PHONE || '+919876543210';
  const contactEmail = APP_CONFIG.CONTACT_EMAIL || 'support@marcosbespoke.com';

  return (
    <View style={[styles.container, { backgroundColor: theme.bg.main }]}>
      {/* Header Bar */}
      <View style={styles.headerBar}>
        <TouchableOpacity 
          style={[styles.headerBtn, shadows.premium]} 
          onPress={() => navigation.goBack()} 
          activeOpacity={0.7}
        >
          <ChevronLeft size={20} color="#1e1e1e" />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { fontFamily: fonts.bold, color: theme.text.primary }]}>
          Privacy Policy
        </Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        
        {/* Banner Card */}
        <View style={[styles.bannerCard, { backgroundColor: theme.brand[500] }, shadows.premium]}>
          <Shield size={28} color="#ffffff" style={{ marginBottom: 8 }} />
          <Text style={[styles.bannerTitle, { fontFamily: fonts.bold }]}>
            Privacy & Data Protection
          </Text>
          <Text style={[styles.bannerSub, { fontFamily: fonts.medium }]}>
            Compliant with GDPR & IT Act Regulations. Protecting your sizing profile, measurements, and personal data.
          </Text>
        </View>

        {/* Section 1: Overview & Consent */}
        <View style={[styles.cardSection, shadows.premium, { backgroundColor: theme.bg.card }]}>
          <View style={styles.cardHeaderRow}>
            <Eye size={18} color={theme.brand[500]} />
            <Text style={[styles.sectionTitle, { fontFamily: fonts.bold, color: theme.text.primary }]}>
              1. Overview & Data Consent
            </Text>
          </View>
          <Text style={[styles.bodyText, { fontFamily: fonts.regular, color: theme.text.secondary }]}>
            At {storeName}, your privacy is paramount. By using our mobile application, self-styling design tools, measurement entry workflows, and payment features, you give your unambiguous consent to the collection and processing of your Personal Data as outlined in this policy.
          </Text>
        </View>

        {/* Section 2: Data We Collect */}
        <View style={[styles.cardSection, shadows.premium, { backgroundColor: theme.bg.card }]}>
          <View style={styles.cardHeaderRow}>
            <FileCheck size={18} color={theme.brand[500]} />
            <Text style={[styles.sectionTitle, { fontFamily: fonts.bold, color: theme.text.primary }]}>
              2. Information We Collect
            </Text>
          </View>
          <Text style={[styles.bodyText, { fontFamily: fonts.regular, color: theme.text.secondary }]}>
            • <Text style={{ fontFamily: fonts.bold }}>Personal Identifiers:</Text> Name, email address, mobile number, shipping address, and sizing preferences.
          </Text>
          <Text style={[styles.bodyText, { fontFamily: fonts.regular, color: theme.text.secondary }]}>
            • <Text style={{ fontFamily: fonts.bold }}>Sizing & Measurement Profiles:</Text> Physical measurement data (chest, waist, shoulder, inseam, etc.) provided for custom stitching.
          </Text>
          <Text style={[styles.bodyText, { fontFamily: fonts.regular, color: theme.text.secondary }]}>
            • <Text style={{ fontFamily: fonts.bold }}>Payment Information:</Text> We do <Text style={{ fontFamily: fonts.bold }}>NOT</Text> store credit/debit card numbers or bank credentials on our servers. All transactions are securely redirected to PCI-DSS certified payment gateways.
          </Text>
          <Text style={[styles.bodyText, { fontFamily: fonts.regular, color: theme.text.secondary }]}>
            • <Text style={{ fontFamily: fonts.bold }}>App Diagnostics:</Text> Anonymous IP address, app performance logs, and device operating system to maintain platform security.
          </Text>
        </View>

        {/* Section 3: Child Data Protection */}
        <View style={[styles.cardSection, shadows.premium, { backgroundColor: theme.bg.card }]}>
          <View style={styles.cardHeaderRow}>
            <Baby size={18} color={theme.brand[500]} />
            <Text style={[styles.sectionTitle, { fontFamily: fonts.bold, color: theme.text.primary }]}>
              3. Child Data Protection Rights
            </Text>
          </View>
          <Text style={[styles.bodyText, { fontFamily: fonts.regular, color: theme.text.secondary }]}>
            We sell custom children's garments for purchase by adults. Users under 18 years of age may only use the app with parental or guardian involvement.
          </Text>
          <View style={[styles.highlightBox, { backgroundColor: theme.bg.input, borderColor: theme.border }]}>
            <Text style={[styles.highlightText, { fontFamily: fonts.medium, color: theme.text.primary }]}>
              • Children's sizing data is strictly protected and never shared with third parties or used for profiling.
            </Text>
            <Text style={[styles.highlightText, { fontFamily: fonts.medium, color: theme.text.primary }]}>
              • Parents/guardians are advised to ensure minor users do not disclose unauthorized personal information.
            </Text>
          </View>
        </View>

        {/* Section 4: Purposes of Data Use */}
        <View style={[styles.cardSection, shadows.premium, { backgroundColor: theme.bg.card }]}>
          <View style={styles.cardHeaderRow}>
            <Cpu size={18} color={theme.brand[500]} />
            <Text style={[styles.sectionTitle, { fontFamily: fonts.bold, color: theme.text.primary }]}>
              4. How We Use Your Information
            </Text>
          </View>
          <Text style={[styles.bodyText, { fontFamily: fonts.regular, color: theme.text.secondary }]}>
            • <Text style={{ fontFamily: fonts.bold }}>Service Fulfillment:</Text> Tailoring garments to measure, processing orders, and arranging doorstep delivery.
          </Text>
          <Text style={[styles.bodyText, { fontFamily: fonts.regular, color: theme.text.secondary }]}>
            • <Text style={{ fontFamily: fonts.bold }}>Customer Support:</Text> Communicating order status, scheduling alterations, and resolving queries.
          </Text>
          <Text style={[styles.bodyText, { fontFamily: fonts.regular, color: theme.text.secondary }]}>
            • <Text style={{ fontFamily: fonts.bold }}>Security & Fraud Prevention:</Text> Detecting illegal activities and safeguarding app infrastructure.
          </Text>
        </View>

        {/* Section 5: GDPR Rights & Play Store Account Deletion */}
        <View style={[styles.cardSection, shadows.premium, { backgroundColor: theme.bg.card }]}>
          <View style={styles.cardHeaderRow}>
            <Trash2 size={18} color={theme.brand[500]} />
            <Text style={[styles.sectionTitle, { fontFamily: fonts.bold, color: theme.text.primary }]}>
              5. GDPR Rights & Account Deletion
            </Text>
          </View>
          <Text style={[styles.bodyText, { fontFamily: fonts.regular, color: theme.text.secondary }]}>
            In compliance with GDPR and Google Play Store policies, you hold full rights over your data, including the <Text style={{ fontFamily: fonts.bold, color: theme.text.primary }}>Right to Access, Rectify, and Erase ('Right to be Forgotten')</Text>.
          </Text>
          <View style={[styles.highlightBox, { backgroundColor: theme.bg.input, borderColor: theme.border }]}>
            <Text style={[styles.highlightText, { fontFamily: fonts.medium, color: theme.text.primary }]}>
              • <Text style={{ fontFamily: fonts.bold }}>How to Delete Account:</Text> You can initiate permanent account and data erasure directly via your Profile settings or by emailing {contactEmail}.
            </Text>
            <Text style={[styles.highlightText, { fontFamily: fonts.medium, color: theme.text.primary }]}>
              • Upon request, all sizing profiles, order records, and credentials will be deleted within 30 days.
            </Text>
          </View>
        </View>

        {/* Section 6: Security Safeguards */}
        <View style={[styles.cardSection, shadows.premium, { backgroundColor: theme.bg.card }]}>
          <View style={styles.cardHeaderRow}>
            <Lock size={18} color={theme.brand[500]} />
            <Text style={[styles.sectionTitle, { fontFamily: fonts.bold, color: theme.text.primary }]}>
              6. Data Security Safeguards
            </Text>
          </View>
          <Text style={[styles.bodyText, { fontFamily: fonts.regular, color: theme.text.secondary }]}>
            We implement SSL encryption, access control tokens, and physical security measures to prevent unauthorized data access. Please keep your account password private and change it periodically.
          </Text>
        </View>

        {/* Section 7: Grievance Officer */}
        <View style={[styles.cardSection, shadows.premium, { backgroundColor: theme.bg.card }]}>
          <Text style={[styles.sectionTitle, { fontFamily: fonts.bold, color: theme.text.primary, marginBottom: 12 }]}>
            Grievance Officer & Support
          </Text>
          <Text style={[styles.bodyText, { fontFamily: fonts.regular, color: theme.text.secondary, marginBottom: 12 }]}>
            Appointed under the Information Technology Act 2000 & Consumer Protection Rules:
          </Text>
          <View style={{ gap: 10 }}>
            <View style={styles.contactRow}>
              <Mail size={16} color={theme.brand[500]} />
              <Text style={[styles.contactText, { fontFamily: fonts.bold, color: theme.text.primary }]}>
                {contactEmail}
              </Text>
            </View>
            <View style={styles.contactRow}>
              <PhoneCall size={16} color={theme.brand[500]} />
              <Text style={[styles.contactText, { fontFamily: fonts.bold, color: theme.text.primary }]}>
                {contactPhone}
              </Text>
            </View>
          </View>
        </View>

        <Text style={[styles.footerText, { fontFamily: fonts.medium, color: theme.text.muted }]}>
          Last Updated: 2026. {storeName}.
        </Text>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 10,
  },
  headerBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 18,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 14,
    paddingBottom: 40,
    gap: 16,
  },
  bannerCard: {
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
  },
  bannerTitle: {
    fontSize: 20,
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: 6,
  },
  bannerSub: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.85)',
    textAlign: 'center',
    lineHeight: 18,
  },
  cardSection: {
    borderRadius: 20,
    padding: 18,
    gap: 10,
  },
  cardHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  sectionTitle: {
    fontSize: 15.5,
  },
  bodyText: {
    fontSize: 13.5,
    lineHeight: 21,
  },
  highlightBox: {
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    gap: 8,
    marginTop: 4,
  },
  highlightText: {
    fontSize: 12.5,
    lineHeight: 18,
  },
  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  contactText: {
    fontSize: 14,
  },
  footerText: {
    fontSize: 11,
    textAlign: 'center',
    marginTop: 16,
  },
});
