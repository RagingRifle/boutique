import { Router } from 'express';
import authRoutes from './auth.routes.js';
import productRoutes from './product.routes.js';
import measurementRoutes from './measurement.routes.js';
import appointmentRoutes from './appointment.routes.js';
import visitRoutes from './visit.routes.js';
import billingRoutes from './billing.routes.js';
import adminRoutes from './admin.routes.js';
import notificationRoutes from './notification.routes.js';
import bannerRoutes from './banner.routes.js';
import ticketRoutes from './ticket.routes.js';
import orderRoutes from './order.routes.js';
import categoryRoutes from './category.routes.js';
import systemRoutes from './system.routes.js';
import { OfferController } from '../controllers/offer.controller.js';
import { StoreLocationController } from '../controllers/storeLocation.controller.js';
import { AdminCategoryController } from '../controllers/adminCategory.controller.js';
import { PromoContentController } from '../controllers/promoContent.controller.js';

const router = Router();

router.use('/auth', authRoutes);
router.use('/products', productRoutes); // Maps both `/products` and `/cart` since they are combined
router.use('/favorites', productRoutes); // Alias for direct /favorites endpoints
router.use('/measurements', measurementRoutes);
router.use('/appointments', appointmentRoutes);
router.use('/visits', visitRoutes);
router.use('/billing', billingRoutes);
router.use('/admin', adminRoutes);
router.use('/notifications', notificationRoutes);
router.use('/banners', bannerRoutes);
router.use('/tickets', ticketRoutes);
router.use('/orders', orderRoutes);
router.use('/categories', categoryRoutes);
router.use('/system', systemRoutes);

// Public endpoints for mobile app
router.get('/offers/active', OfferController.getActiveOffers);
router.get('/stores', StoreLocationController.getPublicStores);

router.get('/promos/active', PromoContentController.getActivePromos);

export default router;
