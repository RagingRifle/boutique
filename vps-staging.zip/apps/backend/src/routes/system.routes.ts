import { Router } from 'express';
import prisma from '../config/db.js';
import redis from '../config/redis.js';
import { isProduction } from '../config/environment.js';

const router = Router();

router.get('/health', async (req, res) => {
  const healthStatus: any = {
    status: 'UP',
    timestamp: new Date(),
    services: {
      database: 'DOWN',
      redis: 'DOWN',
    },
  };

  try {
    await prisma.$queryRaw`SELECT 1`;
    healthStatus.services.database = 'UP';
  } catch (dbError: any) {
    healthStatus.status = 'DEGRADED';
    healthStatus.services.database = isProduction ? 'DOWN' : `DOWN: ${dbError.message}`;
  }

  try {
    const pingResult = await redis.ping();
    if (pingResult === 'PONG') {
      healthStatus.services.redis = 'UP';
    } else {
      healthStatus.status = 'DEGRADED';
      healthStatus.services.redis = `DOWN: Unexpected ping response ${pingResult}`;
    }
  } catch (redisError: any) {
    healthStatus.status = 'DEGRADED';
    healthStatus.services.redis = isProduction ? 'DOWN' : `DOWN: ${redisError.message}`;
  }

  const statusCode = healthStatus.status === 'UP' ? 200 : 500;
  return res.status(statusCode).json(healthStatus);
});

router.get('/settings/public', async (req, res) => {
  try {
    let settings: any = await prisma.systemSettings.findUnique({
      where: { id: 'default' }
    });

    if (!settings) {
      settings = await prisma.systemSettings.create({
        data: {
          id: 'default'
        }
      });
    }

    return res.status(200).json({
      success: true,
      data: {
        businessHoursStart: settings.businessHoursStart,
        businessHoursEnd: settings.businessHoursEnd,
        bookingSlotDurationMinutes: settings.bookingSlotDurationMinutes,
        maxBookingsPerSlot: settings.maxBookingsPerSlot,
        saleAlert: {
          isActive: settings.saleAlertActive || false,
          imageUrl: settings.saleAlertImageUrl || null,
          target: settings.saleAlertTarget || 'NEW_ARRIVALS',
          productId: settings.saleAlertProductId || null,
          durationSec: settings.saleAlertDurationSec || 3,
          startTime: settings.saleAlertStartTime ? settings.saleAlertStartTime.toISOString() : null,
          endTime: settings.saleAlertEndTime ? settings.saleAlertEndTime.toISOString() : null,
        },
        maintenanceAlert: {
          isActive: settings.maintenanceAlertActive || false,
          title: settings.maintenanceTitle || 'System Maintenance',
          message: settings.maintenanceMessage || 'Platform maintenance in progress.',
          startTime: settings.maintenanceStartTime ? settings.maintenanceStartTime.toISOString() : null,
          endTime: settings.maintenanceEndTime ? settings.maintenanceEndTime.toISOString() : null,
        }
      }
    });
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

export default router;
