import { Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import prisma from '../config/db.js';
import JobsProducer from '../queues/jobs.producer.js';

export const broadcastNotificationSchema = z.object({
  body: z.object({
    title: z.string().min(1),
    body: z.string().min(1),
    channels: z.array(z.enum(['EMAIL', 'SMS', 'PUSH'])).optional().default(['EMAIL', 'SMS', 'PUSH']),
    type: z.string().optional(),
    isScheduled: z.boolean().optional(),
    scheduledTime: z.string().optional(),
    targetAudience: z.string().optional().default('ALL'),
  }),
});

export const targetedNotificationSchema = z.object({
  body: z.object({
    userIds: z.array(z.string().uuid()).min(1),
    title: z.string().min(1),
    body: z.string().min(1),
    channels: z.array(z.enum(['EMAIL', 'SMS', 'PUSH'])).optional().default(['EMAIL', 'SMS', 'PUSH']),
  }),
});

export class NotificationController {
  /**
   * PUT /notifications/recipients/:id/read
   * Mark a specific notification as read.
   */
  static async markAsRead(req: Request, res: Response, next: NextFunction) {
    const user = req.user!;
    const { id } = req.params;

    try {
      const recipientRecord = await prisma.notificationRecipient.findUnique({
        where: { id },
      });

      if (!recipientRecord) {
        return res.status(404).json({ success: false, message: 'Notification recipient record not found' });
      }

      if (recipientRecord.userId !== user.id) {
        return res.status(403).json({ success: false, message: 'Forbidden: You do not own this notification' });
      }

      const updated = await prisma.notificationRecipient.update({
        where: { id },
        data: {
          isRead: true,
          readAt: new Date(),
        },
      });

      return res.status(200).json({ success: true, data: updated });
    } catch (error) {
      next(error);
    }
  }

  /**
   * PUT /notifications/recipients/read-all
   * Marks all unread notification recipient records for the logged-in user as read in a single transaction.
   */
  static async markAllAsRead(req: Request, res: Response, next: NextFunction) {
    const user = req.user!;

    try {
      const result = await prisma.notificationRecipient.updateMany({
        where: {
          userId: user.id,
          isRead: false,
        },
        data: {
          isRead: true,
          readAt: new Date(),
        },
      });

      return res.status(200).json({
        success: true,
        updatedCount: result.count,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * GET /notifications/history
   * Retrieve active history of received push notifications.
   */
  static async getHistory(req: Request, res: Response, next: NextFunction) {
    const user = req.user!;
    const { page = 1, limit = 20 } = req.query as any;
    const skip = (Number(page) - 1) * Number(limit);

    try {
      const [history, total] = await Promise.all([
        prisma.notificationRecipient.findMany({
          where: { userId: user.id },
          include: { notification: true },
          orderBy: { notification: { createdAt: 'desc' } },
          skip,
          take: Number(limit),
        }),
        prisma.notificationRecipient.count({ where: { userId: user.id } }),
      ]);

      return res.status(200).json({
        success: true,
        data: history,
        pagination: {
          page: Number(page),
          limit: Number(limit),
          total,
          pages: Math.ceil(total / Number(limit)),
        },
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * POST /notifications/admin/broadcast (Admin Only)
   * Broadcasts a notification blast to all registered customers.
   */
  static async broadcastNotification(req: Request, res: Response, next: NextFunction) {
    const { title, body, channels = ['EMAIL', 'SMS', 'PUSH'], targetAudience = 'ALL', type = 'PROMOTIONAL_BLAST' } = req.body;

    try {
      const notification = await prisma.notification.create({
        data: {
          title,
          body,
          type,
        },
      });

      // Filter target users based on targetAudience
      let whereClause: any = {};
      if (targetAudience === 'CUSTOMERS') {
        whereClause = { role: 'CUSTOMER' };
      } else if (targetAudience === 'STAFF') {
        whereClause = { role: { in: ['STAFF', 'ADMIN', 'SUPERADMIN'] } };
      } else {
        whereClause = {};
      }

      const users = await prisma.user.findMany({
        where: whereClause,
        select: { id: true, email: true, phoneNumber: true, fcmToken: true },
      });

      if (users.length > 0) {
        await prisma.notificationRecipient.createMany({
          data: users.map((u) => ({
            notificationId: notification.id,
            userId: u.id,
          })),
        });

        // 1. Real-time Socket.IO Broadcast to all connected mobile & web clients
        const { getIO } = await import('../socket/socket.handler.js');
        const io = getIO();
        if (io) {
          io.emit('broadcast:alert', {
            id: notification.id,
            title,
            body,
            createdAt: notification.createdAt,
          });

          for (const u of users) {
            io.to(`user:${u.id}`).emit('notification:received', {
              id: notification.id,
              title,
              body,
              createdAt: notification.createdAt,
            });
          }
        }

        // 2. Dispatch FCM Push Notifications directly
        const { NotificationService } = await import('../services/notification.service.js');
        for (const u of users) {
          if (u.fcmToken) {
            NotificationService.sendPushNotification(u.id, title, body).catch(() => {});
          }

          JobsProducer.queueNotification({
            userId: u.id,
            channels,
            templates: {
              email: { id: 'broadcast', data: { title, body } },
              sms: body,
              push: { title, body },
            },
          }).catch(() => {});
        }
      }

      return res.status(201).json({
        success: true,
        message: `Broadcast dispatched successfully for ${users.length} users.`,
        data: notification,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * POST /notifications/admin/send (Admin Only)
   * Sends targeted notification alert to specific users.
   */
  static async sendTargetedNotification(req: Request, res: Response, next: NextFunction) {
    const { userIds, title, body, channels } = req.body;

    try {
      const notification = await prisma.notification.create({
        data: {
          title,
          body,
          type: 'ORDER_UPDATE',
        },
      });

      await prisma.notificationRecipient.createMany({
        data: userIds.map((uid: string) => ({
          notificationId: notification.id,
          userId: uid,
        })),
      });

      for (const uid of userIds) {
        await JobsProducer.queueNotification({
          userId: uid,
          channels,
          templates: {
            email: { id: 'alert', data: { title, body } },
            sms: body,
            push: { title, body },
          },
        });
      }

      return res.status(201).json({
        success: true,
        message: `Targeted notification queued successfully for ${userIds.length} users.`,
        data: notification,
      });
    } catch (error) {
      next(error);
    }
  }
}
