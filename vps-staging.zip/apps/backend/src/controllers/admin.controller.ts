import { Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import crypto from 'crypto';
import prisma from '../config/db.js';
import { Role } from '@prisma/client';
import { createAuditLog } from '../utils/audit.js';
import { hashPassword } from '../utils/crypto.js';
import { R2Service } from '../services/r2.service.js';
import { CloudinaryService } from '../services/cloudinary.service.js';
import redis from '../config/redis.js';
import env from '../config/env.js';
import { isDevelopment } from '../config/environment.js';
import AuthService from '../services/auth.service.js';

export const loyaltyAdjustSchema = z.object({
  body: z.object({
    userId: z.string().uuid(),
    points: z.coerce.number().int(),
    reason: z.string().min(1),
  }),
});

export const userRoleUpdateSchema = z.object({
  body: z.object({
    role: z.enum(['CUSTOMER', 'STAFF', 'ADMIN']),
  }),
});

export const userUpdateSchema = z.object({
  body: z.object({
    fullName: z.string().optional(),
    role: z.enum(['CUSTOMER', 'STAFF', 'ADMIN']).optional(),
  }),
});

export const staffCreateSchema = z.object({
  body: z.object({
    fullName: z.string().min(1),
    email: z.string().email(),
    phoneNumber: z.string().min(1),
    role: z.enum(['STAFF', 'ADMIN']),
  }),
});

export const systemSettingsUpdateSchema = z.object({
  body: z.object({
    lowStockThreshold: z.coerce.number().int().nonnegative().default(10),
    businessHoursStart: z.string().min(1),
    businessHoursEnd: z.string().min(1),
    businessHours: z.any().optional(),
    bookingSlotDurationMinutes: z.coerce.number().int().min(5).default(60),
    maxBookingsPerSlot: z.coerce.number().int().min(1).default(5),
    pointsEarnRate: z.coerce.number().int().nonnegative().default(10),
    pointsRedeemRate: z.coerce.number().nonnegative().default(0.10),
    otpCooldownMinutes: z.coerce.number().int().nonnegative().default(15),
    maxOtpFailures: z.coerce.number().int().nonnegative().default(3),

    // Sale Alert
    saleAlertActive: z.boolean().optional(),
    saleAlertImageUrl: z.string().optional().nullable(),
    saleAlertTarget: z.enum(['NEW_ARRIVALS', 'TRENDING', 'PRODUCT']).optional(),
    saleAlertProductId: z.string().optional().nullable(),
    saleAlertDurationSec: z.coerce.number().int().min(1).default(3),
    saleAlertStartTime: z.string().optional().nullable(),
    saleAlertEndTime: z.string().optional().nullable(),

    // Maintenance Alert
    maintenanceAlertActive: z.boolean().optional(),
    maintenanceTitle: z.string().optional().nullable(),
    maintenanceMessage: z.string().optional().nullable(),
    maintenanceStartTime: z.string().optional().nullable(),
    maintenanceEndTime: z.string().optional().nullable(),
  }),
});

export const couponCreateSchema = z.object({
  body: z.object({
    code: z.string().min(1),
    discountPercent: z.coerce.number().int().min(0).max(100).default(0),
    discountFlat: z.coerce.number().nonnegative().default(0),
    maxDiscount: z.coerce.number().positive().optional().nullable(),
    expiryDate: z.string().datetime(),
    maxUses: z.coerce.number().int().positive().default(100),
  }),
});

export class AdminController {
  /**
   * GET /admin/dashboard
   * Aggregates total revenue, order count, pending visits, and monthly trends for Recharts.
   */
  static async getDashboard(req: Request, res: Response, next: NextFunction) {
    try {
      const getStartOfWeekUTC = (date: Date): Date => {
        const d = new Date(date);
        const day = d.getUTCDay();
        d.setUTCDate(d.getUTCDate() - day);
        d.setUTCHours(0, 0, 0, 0);
        return d;
      };

      const oldestOrder = await prisma.order.findFirst({
        orderBy: { createdAt: 'asc' },
        select: { createdAt: true }
      });
      const oldestDate = oldestOrder ? oldestOrder.createdAt : new Date();
      const oldestWeekStart = getStartOfWeekUTC(oldestDate);
      const currentWeekStart = getStartOfWeekUTC(new Date());

      const availableWeeks: { start: string; label: string }[] = [];
      const tempDate = new Date(currentWeekStart);
      while (tempDate >= oldestWeekStart) {
        const startStr = tempDate.toISOString().substring(0, 10);
        const endOfWeek = new Date(tempDate);
        endOfWeek.setUTCDate(endOfWeek.getUTCDate() + 6);
        
        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        const startMonth = monthNames[tempDate.getUTCMonth()];
        const startDay = tempDate.getUTCDate();
        const endMonth = monthNames[endOfWeek.getUTCMonth()];
        const endDay = endOfWeek.getUTCDate();
        
        let label = `${startMonth} ${startDay} - ${endMonth} ${endDay}, ${tempDate.getUTCFullYear()}`;
        if (tempDate.getTime() === currentWeekStart.getTime()) {
          label += " (This Week)";
        } else if (tempDate.getTime() === currentWeekStart.getTime() - 7 * 24 * 60 * 60 * 1000) {
          label += " (Last Week)";
        }
        
        availableWeeks.push({ start: startStr, label });
        tempDate.setUTCDate(tempDate.getUTCDate() - 7);
      }

      let defaultWeekStart = currentWeekStart;
      if (availableWeeks.length > 1) {
        defaultWeekStart = new Date(availableWeeks[1].start + "T00:00:00.000Z");
      }

      const queryWeekStartStr = req.query.weekStart as string;
      const selectedWeekStart = queryWeekStartStr ? new Date(`${queryWeekStartStr}T00:00:00.000Z`) : defaultWeekStart;
      const selectedWeekStartStr = selectedWeekStart.toISOString().substring(0, 10);

      const cacheKey = `cache:admin:dashboard:${selectedWeekStartStr}`;
      const cached = await redis.get(cacheKey);
      if (cached) return res.status(200).json(JSON.parse(cached));

      const now = new Date();
      const firstDayThisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const firstDayLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);

      // 1. Overview aggregates (use count/aggregate instead of fetching full objects)
      const [
        ordThis, ordLast,
        revenueThisMonth, revenueLastMonth,
        cartEventsThis, checkoutEventsThis,
        cartEventsLast, checkoutEventsLast
      ] = await Promise.all([
        prisma.order.count({ where: { status: { not: 'CANCELLED' }, createdAt: { gte: firstDayThisMonth } } }),
        prisma.order.count({ where: { status: { not: 'CANCELLED' }, createdAt: { gte: firstDayLastMonth, lt: firstDayThisMonth } } }),
        prisma.order.aggregate({ where: { status: { not: 'CANCELLED' }, createdAt: { gte: firstDayThisMonth } }, _sum: { payableAmount: true } }),
        prisma.order.aggregate({ where: { status: { not: 'CANCELLED' }, createdAt: { gte: firstDayLastMonth, lt: firstDayThisMonth } }, _sum: { payableAmount: true } }),
        prisma.analyticsEvent.count({ where: { eventType: 'ADD_TO_CART', createdAt: { gte: firstDayThisMonth } } }),
        prisma.analyticsEvent.count({ where: { eventType: 'CHECKOUT_INITIATED', createdAt: { gte: firstDayThisMonth } } }),
        prisma.analyticsEvent.count({ where: { eventType: 'ADD_TO_CART', createdAt: { gte: firstDayLastMonth, lt: firstDayThisMonth } } }),
        prisma.analyticsEvent.count({ where: { eventType: 'CHECKOUT_INITIATED', createdAt: { gte: firstDayLastMonth, lt: firstDayThisMonth } } })
      ]);

      const revThis = Number(revenueThisMonth._sum.payableAmount || 0);
      const revLast = Number(revenueLastMonth._sum.payableAmount || 0);
      const revDiff = revLast === 0 ? 100 : Math.round(((revThis - revLast) / revLast) * 100);

      const ordDiff = ordLast === 0 ? 100 : Math.round(((ordThis - ordLast) / ordLast) * 100);

      const aovThis = ordThis === 0 ? 0 : Math.round(revThis / ordThis);
      const aovLast = ordLast === 0 ? 0 : Math.round(revLast / ordLast);
      const aovDiff = aovLast === 0 ? 100 : Math.round(((aovThis - aovLast) / aovLast) * 100);

      // Cart Abandon Rate (counts already fetched from DB in parallel)
      const cartAbandonRateThis = cartEventsThis === 0 ? 0 : Math.round(((cartEventsThis - checkoutEventsThis) / cartEventsThis) * 100);
      const cartAbandonRateLast = cartEventsLast === 0 ? 0 : Math.round(((cartEventsLast - checkoutEventsLast) / cartEventsLast) * 100);
      const cartAbandonDiff = cartAbandonRateThis - cartAbandonRateLast;

      // 2. Product Sales Performance (units sold this month)
      const [productSalesAgg, products] = await Promise.all([
        prisma.orderItem.groupBy({
          by: ['productId'],
          where: { order: { status: { not: 'CANCELLED' }, createdAt: { gte: firstDayThisMonth } } },
          _sum: { quantity: true },
        }),
        prisma.product.findMany({
          select: { id: true, name: true, inventoryQty: true }
        })
      ]);

      const salesMap = new Map(productSalesAgg.map(item => [item.productId, item._sum.quantity || 0]));

      const productSales = products.map(p => ({
        id: p.id, name: p.name, unitsSold: salesMap.get(p.id) || 0, stock: p.inventoryQty
      }));
      productSales.sort((a, b) => b.unitsSold - a.unitsSold);
      const topSelling = productSales;
      const lowestSelling = [...productSales].sort((a, b) => a.unitsSold - b.unitsSold);

      // 3 & 4. Product Views, Cart Activity, Conversion
      // Use database-level aggregation instead of fetching all events into memory
      const [eventsByProduct, funnelCounts, activeCartAgg] = await Promise.all([
        prisma.analyticsEvent.groupBy({
          by: ['productId', 'eventType'],
          where: { productId: { not: null } },
          _count: { id: true },
        }),
        prisma.analyticsEvent.groupBy({
          by: ['eventType'],
          _count: { id: true },
        }),
        prisma.cartItem.groupBy({
          by: ['productId'],
          _sum: { quantity: true },
        }),
      ]);

      const viewMap = new Map<string, number>();
      const cartMap = new Map<string, number>();
      const purchaseMap = new Map<string, number>();
      const abandonMap = new Map<string, number>();

      eventsByProduct.forEach(e => {
        if (!e.productId) return;
        const count = e._count.id;
        switch (e.eventType) {
          case 'PRODUCT_VIEW': viewMap.set(e.productId, count); break;
          case 'ADD_TO_CART': cartMap.set(e.productId, count); break;
          case 'PURCHASE_COMPLETED': purchaseMap.set(e.productId, count); break;
          case 'CART_ABANDONED': abandonMap.set(e.productId, count); break;
        }
      });

      // Augment with real-time active cart data (already aggregated per product at DB level)
      activeCartAgg.forEach(ci => {
        const qty = ci._sum.quantity || 0;
        cartMap.set(ci.productId, (cartMap.get(ci.productId) || 0) + qty);
        abandonMap.set(ci.productId, (abandonMap.get(ci.productId) || 0) + qty);
      });

      const productInsights = products.map(p => ({
        id: p.id, name: p.name,
        views: viewMap.get(p.id) || 0,
        addedToCart: cartMap.get(p.id) || 0,
        purchased: purchaseMap.get(p.id) || 0,
        abandoned: abandonMap.get(p.id) || 0,
        conversionRate: (cartMap.get(p.id) || 0) > 0 ? Math.round(((purchaseMap.get(p.id) || 0) / cartMap.get(p.id)!) * 100) : 0
      }));

      const mostViewed = [...productInsights].sort((a, b) => b.views - a.views);
      const leastViewed = [...productInsights].sort((a, b) => a.views - b.views);
      const mostAdded = [...productInsights].sort((a, b) => b.addedToCart - a.addedToCart);
      const leastAdded = [...productInsights].sort((a, b) => a.addedToCart - b.addedToCart);
      const topConverters = [...productInsights].sort((a, b) => b.conversionRate - a.conversionRate).filter(p => p.addedToCart > 0);
      const mostAbandoned = [...productInsights].sort((a, b) => b.abandoned - a.abandoned);

      // 5. Conversion Funnel (uses pre-aggregated counts from DB)
      const funnelMap = new Map(funnelCounts.map(e => [e.eventType, e._count.id]));
      const funnel = {
        views: funnelMap.get('PRODUCT_VIEW') || 0,
        addedToCart: funnelMap.get('ADD_TO_CART') || 0,
        reachedCheckout: funnelMap.get('CHECKOUT_INITIATED') || 0,
        purchased: funnelMap.get('PURCHASE_COMPLETED') || 0,
      };

      // 6. City Intelligence
      const startOfPeriod = new Date(now.getFullYear() - 1, 0, 1);
      
      const selectedWeekStartMs = selectedWeekStart.getTime();
      const selectedWeekEndMs = selectedWeekStartMs + 7 * 24 * 60 * 60 * 1000;
      const prevWeekStartMs = selectedWeekStartMs - 7 * 24 * 60 * 60 * 1000;
      const prevWeekEndMs = selectedWeekStartMs;
      const lyWeekStartMs = selectedWeekStartMs - 52 * 7 * 24 * 60 * 60 * 1000;
      const lyWeekEndMs = lyWeekStartMs + 7 * 24 * 60 * 60 * 1000;

      const [userOrderStats, guestOrderStats, peakHoursRaw, seasonalTrendRaw, weeklyComparisonRaw] = await Promise.all([
        prisma.order.groupBy({
          by: ['userId'],
          where: { status: { not: 'CANCELLED' }, createdAt: { gte: startOfPeriod }, userId: { not: null } },
          _count: { id: true },
          _sum: { payableAmount: true }
        }),
        prisma.order.aggregate({
          where: { status: { not: 'CANCELLED' }, createdAt: { gte: startOfPeriod }, userId: null },
          _count: { id: true },
          _sum: { payableAmount: true }
        }),
        prisma.$queryRaw`
          SELECT 
            EXTRACT(ISODOW FROM "createdAt") as dow, 
            EXTRACT(HOUR FROM "createdAt") as hour, 
            COUNT(*)::int as count
          FROM "Order"
          WHERE "createdAt" >= ${startOfPeriod} AND "status" != 'CANCELLED'
          GROUP BY dow, hour
        ` as Promise<any[]>,
        prisma.$queryRaw`
          SELECT 
            EXTRACT(YEAR FROM "createdAt") as year, 
            EXTRACT(MONTH FROM "createdAt") as month, 
            SUM("payableAmount") as revenue
          FROM "Order"
          WHERE "createdAt" >= ${startOfPeriod} AND "status" != 'CANCELLED'
          GROUP BY year, month
        ` as Promise<any[]>,
        prisma.$queryRaw`
          SELECT 
            EXTRACT(ISODOW FROM "createdAt") as dow,
            SUM(CASE WHEN "createdAt" >= ${new Date(selectedWeekStartMs)} AND "createdAt" < ${new Date(selectedWeekEndMs)} THEN "payableAmount" ELSE 0 END) as this_week,
            SUM(CASE WHEN "createdAt" >= ${new Date(prevWeekStartMs)} AND "createdAt" < ${new Date(prevWeekEndMs)} THEN "payableAmount" ELSE 0 END) as last_week,
            SUM(CASE WHEN "createdAt" >= ${new Date(lyWeekStartMs)} AND "createdAt" < ${new Date(lyWeekEndMs)} THEN "payableAmount" ELSE 0 END) as same_week_last_year
          FROM "Order"
          WHERE "status" != 'CANCELLED' 
            AND (
              ("createdAt" >= ${new Date(selectedWeekStartMs)} AND "createdAt" < ${new Date(selectedWeekEndMs)}) OR
              ("createdAt" >= ${new Date(prevWeekStartMs)} AND "createdAt" < ${new Date(prevWeekEndMs)}) OR
              ("createdAt" >= ${new Date(lyWeekStartMs)} AND "createdAt" < ${new Date(lyWeekEndMs)})
            )
          GROUP BY dow
        ` as Promise<any[]>
      ]);

      const userIds = userOrderStats.map(u => u.userId as string);
      const users = await prisma.user.findMany({
        where: { id: { in: userIds } },
        select: { id: true, address: true }
      });
      const userAddressMap = new Map(users.map(u => [u.id, u.address]));

      const cityMap = new Map();
      userOrderStats.forEach(stat => {
        const address = userAddressMap.get(stat.userId as string);
        let city = 'Unknown';
        if (address) {
          try {
            let parsed = JSON.parse(address);
            if (Array.isArray(parsed) && parsed.length > 0) parsed = parsed[0];
            if (parsed.city) city = parsed.city;
            else if (parsed.addressLine1) city = parsed.city || 'Unknown';
            else city = 'Unknown';
          } catch (e) {
            const parts = address.split(',').map(p => p.trim());
            if (parts.length >= 3) city = parts[parts.length - 3];
            else if (parts.length > 0) city = parts[parts.length - 1];
          }
        }
        if (!cityMap.has(city)) cityMap.set(city, { orders: 0, customers: new Set(), revenue: 0 });
        const c = cityMap.get(city);
        c.orders += stat._count.id;
        c.customers.add(stat.userId);
        c.revenue += Number(stat._sum.payableAmount || 0);
      });

      if (guestOrderStats._count.id > 0) {
        if (!cityMap.has('Unknown')) cityMap.set('Unknown', { orders: 0, customers: new Set(), revenue: 0 });
        const c = cityMap.get('Unknown');
        c.orders += guestOrderStats._count.id;
        c.revenue += Number(guestOrderStats._sum.payableAmount || 0);
      }

      const cityInsights = Array.from(cityMap.entries()).map(([city, data]) => ({
        city,
        orders: data.orders,
        customers: data.customers.size,
        aov: data.orders > 0 ? Math.round(data.revenue / data.orders) : 0
      }));

      const ordersByCity = [...cityInsights].sort((a, b) => b.orders - a.orders);
      const customersByCity = [...cityInsights].sort((a, b) => b.customers - a.customers);
      const aovByCity = [...cityInsights].sort((a, b) => b.aov - a.aov);

      // 7. Peak Order Hours
      const hoursMap = new Array(7).fill(0).map(() => new Array(24).fill(0));
      peakHoursRaw.forEach(row => {
        let dow = Number(row.dow) - 1;
        if (dow === -1) dow = 6;
        const hour = Number(row.hour);
        hoursMap[dow][hour] = Number(row.count);
      });

      // 8. Stock Risk Alert
      const stockRisk = products
        .filter(p => p.inventoryQty < 10)
        .map(p => {
          const recentSales = salesMap.get(p.id) || 0;
          let demandLevel = 'Low demand';
          if (recentSales > 20) demandLevel = 'Very High demand';
          else if (recentSales > 5) demandLevel = 'High demand';
          else if (recentSales > 0) demandLevel = 'Moderate demand';
          return { id: p.id, name: p.name, stock: p.inventoryQty, demand: demandLevel, recentSales };
        })
        .sort((a, b) => b.recentSales - a.recentSales);

      // 9. Time-Based Patterns
      const currentYear = new Date().getFullYear();

      const seasonalTrend = Array.from({ length: 12 }, (_, i) => ({
        month: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][i],
        thisYear: 0,
        lastYear: 0,
        festival: i === 9 || i === 10
      }));

      seasonalTrendRaw.forEach(row => {
        const y = Number(row.year);
        const m = Number(row.month) - 1;
        if (m >= 0 && m <= 11) {
          if (y === currentYear) seasonalTrend[m].thisYear = Number(row.revenue);
          if (y === currentYear - 1) seasonalTrend[m].lastYear = Number(row.revenue);
        }
      });

      const dayOfWeekPattern = Array.from({ length: 7 }, (_, i) => ({
        day: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i],
        revenue: 0
      }));

      const weeklyComparison = Array.from({ length: 7 }, (_, i) => ({
        day: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i],
        thisWeek: 0,
        lastWeek: 0,
        sameWeekLastYear: 0
      }));

      weeklyComparisonRaw.forEach(row => {
        let dow = Number(row.dow) - 1;
        if (dow >= 0 && dow <= 6) {
          weeklyComparison[dow].thisWeek = Number(row.this_week);
          weeklyComparison[dow].lastWeek = Number(row.last_week);
          weeklyComparison[dow].sameWeekLastYear = Number(row.same_week_last_year);
          dayOfWeekPattern[dow].revenue = Number(row.this_week);
        }
      });

      const todayStart = new Date();
      todayStart.setUTCHours(0, 0, 0, 0);
      const todayEnd = new Date(todayStart);
      todayEnd.setUTCDate(todayEnd.getUTCDate() + 1);

      const tomorrowStart = new Date(todayEnd);
      const tomorrowEnd = new Date(tomorrowStart);
      tomorrowEnd.setUTCDate(tomorrowEnd.getUTCDate() + 1);

      const todayOrdersCount = await prisma.order.count({
        where: { createdAt: { gte: todayStart, lt: todayEnd }, status: { not: 'CANCELLED' } }
      });
      
      const todayDeliveriesCount = await prisma.order.count({
        where: { status: 'DELIVERED', updatedAt: { gte: todayStart, lt: todayEnd } }
      });
      
      const tomorrowOrdersList = await prisma.order.findMany({
        where: { quickOrderExpectedDate: { gte: tomorrowStart, lt: tomorrowEnd } },
        include: { user: true },
        take: 5
      });
      
      const tomorrowAppointmentsList = await prisma.appointment.findMany({
        where: { date: { gte: tomorrowStart, lt: tomorrowEnd } },
        include: { user: true },
        take: 5
      });

      const responsePayload = {
        success: true,
        data: {
          todayStats: {
            orders: todayOrdersCount,
            deliveries: todayDeliveriesCount,
            tomorrowDetails: {
              orders: tomorrowOrdersList,
              appointments: tomorrowAppointmentsList
            }
          },
          availableWeeks,
          selectedWeekStart: selectedWeekStartStr,
          timeBasedPatterns: {
            seasonalTrend,
            dayOfWeekPattern,
            weeklyComparison
          },
          overview: {
            revenue: { value: revThis, diff: revDiff },
            orders: { value: ordThis, diff: ordDiff },
            aov: { value: aovThis, diff: aovDiff },
            abandonRate: { value: cartAbandonRateThis, diff: cartAbandonDiff }
          },
          productSales: { topSelling, lowestSelling },
          productViews: { mostViewed, leastViewed },
          cartActivity: { mostAdded, leastAdded },
          conversion: { topConverters, mostAbandoned },
          funnel,
          cityIntelligence: { ordersByCity, customersByCity, aovByCity },
          peakHours: hoursMap,
          stockRisk
        }
      };

      await redis.set(cacheKey, JSON.stringify(responsePayload), 'EX', 600);
      return res.status(200).json(responsePayload);
    } catch (error) {
      next(error);
    }
  }

  /**
   * GET /admin/dashboard/date-stats?date=YYYY-MM-DD
   * Returns order count, delivery count, and appointments for any given date.
   * Defaults to today if no date is provided.
   */
  static async getDateStats(req: Request, res: Response, next: NextFunction) {
    try {
      const dateParam = req.query.date as string;

      // Parse the requested date (local midnight IST → UTC range for the full day)
      let dayStart: Date;
      if (dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam)) {
        dayStart = new Date(`${dateParam}T00:00:00.000Z`);
      } else {
        dayStart = new Date();
        dayStart.setUTCHours(0, 0, 0, 0);
      }

      const dayEnd = new Date(dayStart);
      dayEnd.setUTCDate(dayEnd.getUTCDate() + 1);

      const nextDayStart = new Date(dayEnd);
      const nextDayEnd = new Date(nextDayStart);
      nextDayEnd.setUTCDate(nextDayEnd.getUTCDate() + 1);

      const cacheKey = `cache:admin:date-stats:${dayStart.toISOString().substring(0, 10)}`;
      const cached = await redis.get(cacheKey);
      if (cached) {
        return res.status(200).json(JSON.parse(cached));
      }

      const [ordersCount, deliveriesCount, ordersList, appointmentsList, nextDayOrders, nextDayAppts] = await Promise.all([
        prisma.order.count({
          where: { createdAt: { gte: dayStart, lt: dayEnd }, status: { not: 'CANCELLED' } }
        }),
        prisma.order.count({
          where: { status: 'DELIVERED', updatedAt: { gte: dayStart, lt: dayEnd } }
        }),
        prisma.order.findMany({
          where: { createdAt: { gte: dayStart, lt: dayEnd }, status: { not: 'CANCELLED' } },
          include: { user: { select: { fullName: true } }, orderItems: { include: { product: { select: { name: true } } } } },
          orderBy: { createdAt: 'desc' },
          take: 10
        }),
        prisma.appointment.findMany({
          where: { date: { gte: dayStart, lt: dayEnd } },
          include: { user: { select: { fullName: true } } },
          orderBy: { date: 'asc' },
          take: 10
        }),
        prisma.order.findMany({
          where: { quickOrderExpectedDate: { gte: nextDayStart, lt: nextDayEnd } },
          include: { user: { select: { fullName: true } } },
          take: 5
        }),
        prisma.appointment.findMany({
          where: { date: { gte: nextDayStart, lt: nextDayEnd } },
          include: { user: { select: { fullName: true } } },
          take: 5
        }),
      ]);

      const responsePayload = {
        success: true,
        data: {
          date: dayStart.toISOString().substring(0, 10),
          orders: ordersCount,
          deliveries: deliveriesCount,
          ordersList,
          appointmentsList,
          nextDayDetails: {
            orders: nextDayOrders,
            appointments: nextDayAppts,
          }
        }
      };

      await redis.set(cacheKey, JSON.stringify(responsePayload), 'EX', 120);
      return res.status(200).json(responsePayload);
    } catch (error) {
      next(error);
    }
  }

  /**
   * POST /admin/loyalty/adjust
   * Adds or deducts customer loyalty points. Checks floor limit (points balance cannot drop below 0).
   */
  static async adjustPoints(req: Request, res: Response, next: NextFunction) {
    const adminUser = req.user!;
    const { userId, points, reason } = req.body;

    try {
      // Execute entirely within transaction to prevent TOCTOU race conditions
      const updatedUser = await prisma.$transaction(async (tx: any) => {
        // Read user inside transaction for consistent snapshot
        const user = await tx.user.findUnique({
          where: { id: userId },
        });

        if (!user) {
          throw new Error('USER_NOT_FOUND');
        }

        const newBalance = user.pointsBalance + points;
        if (newBalance < 0) {
          throw new Error(`INSUFFICIENT_BALANCE:${user.pointsBalance}`);
        }

        // Use atomic increment to prevent concurrent modification
        const updated = await tx.user.update({
          where: { id: userId },
          data: { pointsBalance: { increment: points } },
        });

        // Safety check: ensure balance didn't go negative due to concurrent adjustments
        if (updated.pointsBalance < 0) {
          throw new Error(`INSUFFICIENT_BALANCE:${user.pointsBalance}`);
        }

        await tx.pointTransaction.create({
          data: {
            userId,
            points,
            reason,
          },
        });

        // Log manual adjustments in AuditLog
        await tx.auditLog.create({
          data: {
            userId: adminUser.id,
            action: 'POINTS_MANUALLY_ADJUSTED',
            ipAddress: req.ip,
            details: {
              message: `Admin ${adminUser.fullName} adjusted user ${user.fullName} points. Delta: ${points}, New Balance: ${updated.pointsBalance}`,
              targetUserId: userId,
              delta: points,
              reason,
            },
          },
        });

        return updated;
      });

      return res.status(200).json({
        success: true,
        message: 'Loyalty points adjusted successfully',
        data: {
          userId: updatedUser.id,
          pointsBalance: updatedUser.pointsBalance,
        },
      });
    } catch (error: any) {
      if (error.message === 'USER_NOT_FOUND') {
        return res.status(404).json({ success: false, message: 'User not found' });
      }
      if (error.message?.startsWith('INSUFFICIENT_BALANCE:')) {
        const currentBalance = error.message.split(':')[1];
        return res.status(400).json({
          success: false,
          message: `Adjustment failed. User points balance (${currentBalance}) cannot drop below zero. Requested adjust: ${points}`,
        });
      }
      next(error);
    }
  }

  /**
   * GET /admin/loyalty/transactions
   */
  static async listPointTransactions(req: Request, res: Response, next: NextFunction) {
    const { page = 1, limit = 50 } = req.query as any;
    const skip = (Number(page) - 1) * Number(limit);

    try {
      const [transactions, total] = await Promise.all([
        prisma.pointTransaction.findMany({
          orderBy: { createdAt: 'desc' },
          skip,
          take: Number(limit),
          include: {
            user: {
              select: {
                fullName: true,
              },
            },
          },
        }),
        prisma.pointTransaction.count(),
      ]);

      return res.status(200).json({
        success: true,
        data: transactions.map(t => ({
          ...t,
          userName: t.user?.fullName || 'Customer',
        })),
        pagination: {
          page: Number(page),
          limit: Number(limit),
          total,
          pages: Math.ceil(total / Number(limit)),
        },
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * GET /admin/reports
   * Generates extended analytics reports (customer growth trends, product sales performance, and low stock inventory alerts)
   */
  static async getExtendedReports(req: Request, res: Response, next: NextFunction) {
    const cacheKey = 'cache:admin:extended-reports';
    try {
      const cached = await redis.get(cacheKey);
      if (cached) return res.status(200).json(JSON.parse(cached));

      const sixMonthsAgo = new Date();
      sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

      // 1. Customer Growth Trend
      // Use raw SQL to group by month and avoid fetching thousands of user records into Node memory
      const growthData: any[] = await prisma.$queryRaw`
        SELECT 
          TO_CHAR("createdAt", 'Mon YY') as month,
          COUNT(*) as count
        FROM "User"
        WHERE role = 'CUSTOMER' AND "createdAt" >= ${sixMonthsAgo}
        GROUP BY TO_CHAR("createdAt", 'Mon YY'), DATE_TRUNC('month', "createdAt")
        ORDER BY DATE_TRUNC('month', "createdAt") ASC
      `;

      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const growthMap = new Map<string, number>();

      for (let i = 5; i >= 0; i--) {
        const d = new Date();
        d.setMonth(d.getMonth() - i);
        const key = `${months[d.getMonth()]} ${d.getFullYear().toString().substring(2)}`;
        growthMap.set(key, 0);
      }

      // Merge the SQL results into our zero-filled map to ensure all 6 months are present
      growthData.forEach(row => {
        const key = row.month; // e.g. "Jul 26"
        if (growthMap.has(key)) {
          // prisma $queryRaw returns BigInt for count, so we cast to Number
          growthMap.set(key, Number(row.count));
        }
      });

      const growthChart = Array.from(growthMap.entries()).map(([month, count]) => ({
        month,
        count,
      }));

      // 2. Product Sales Performance
      const salesGrouping = await prisma.orderItem.groupBy({
        by: ['productId'],
        _sum: { quantity: true },
        orderBy: { _sum: { quantity: 'desc' } },
        take: 5,
      });

      const productIds = salesGrouping.map((s: any) => s.productId);
      const products = await prisma.product.findMany({
        where: { id: { in: productIds } },
        select: { id: true, name: true, price: true },
      });

      const performanceChart = salesGrouping.map((s: any) => {
        const prod = products.find((p) => p.id === s.productId);
        return {
          productId: s.productId,
          productName: prod ? prod.name : 'Unknown Product',
          quantitySold: s._sum.quantity || 0,
          revenueGenerated: (s._sum.quantity || 0) * Number(prod ? prod.price : 0),
        };
      });

      // 3. Low Stock / Inventory Alerts
      const lowStockAlerts = await prisma.product.findMany({
        where: {
          OR: [
            { inventoryQty: { lte: 5 } },
            { stockStatus: { in: ['LOW_STOCK', 'OUT_OF_STOCK'] } },
          ],
        },
        select: {
          id: true,
          name: true,
          inventoryQty: true,
          stockStatus: true,
        },
      });

      const responsePayload = {
        success: true,
        data: {
          customerGrowth: growthChart,
          productPerformance: performanceChart,
          lowStockAlerts,
        },
      };

      await redis.set(cacheKey, JSON.stringify(responsePayload), 'EX', 300);
      return res.status(200).json(responsePayload);
    } catch (error) {
      next(error);
    }
  }

  /**
   * PUT /admin/users/:id/role
   * SuperAdmin Only
   */
  static async updateUserRole(req: Request, res: Response, next: NextFunction) {
    const { id } = req.params;
    const { role } = req.body;

    try {
      const targetUser = await prisma.user.findUnique({ where: { id } });
      if (!targetUser) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }

      const updated = await prisma.user.update({
        where: { id },
        data: { role: role as Role },
      });

      await createAuditLog({
        userId: req.user!.id,
        action: 'USER_ROLE_CHANGED',
        ipAddress: req.ip,
        details: {
          message: `SuperAdmin ${req.user!.fullName} changed role of user ${targetUser.fullName} (ID: ${id}) from ${targetUser.role} to ${role}`,
          targetUserId: id,
          previousRole: targetUser.role,
          newRole: role,
        },
      });

      return res.status(200).json({ success: true, message: 'User role updated successfully', data: updated });
    } catch (error) {
      next(error);
    }
  }

  /**
   * GET /admin/coupons
   */
  static async listCoupons(req: Request, res: Response, next: NextFunction) {
    try {
      const coupons = await prisma.coupon.findMany({
        orderBy: { createdAt: 'desc' },
      });

      return res.status(200).json({
        success: true,
        data: coupons,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * POST /admin/coupons
   */
  static async createCoupon(req: Request, res: Response, next: NextFunction) {
    const { code, discountPercent, discountFlat, maxDiscount, expiryDate, maxUses } = req.body;

    try {
      const existing = await prisma.coupon.findUnique({ where: { code } });
      if (existing) {
        return res.status(409).json({ success: false, message: 'Coupon code already exists' });
      }

      const coupon = await prisma.coupon.create({
        data: {
          code,
          discountPercent,
          discountFlat,
          maxDiscount,
          expiryDate: new Date(expiryDate),
          maxUses,
        },
      });

      await createAuditLog({
        userId: req.user!.id,
        action: 'COUPON_CREATED',
        ipAddress: req.ip,
        details: {
          message: `Coupon '${code}' created by ${req.user!.fullName}`,
          couponId: coupon.id,
          code,
          discountPercent,
          discountFlat,
          maxDiscount,
          expiryDate,
          maxUses,
        },
      });

      return res.status(201).json({ success: true, message: 'Coupon created successfully', data: coupon });
    } catch (error) {
      next(error);
    }
  }

  /**
   * PUT /admin/coupons/:id/deactivate
   */
  static async deactivateCoupon(req: Request, res: Response, next: NextFunction) {
    const { id } = req.params;

    try {
      const existing = await prisma.coupon.findUnique({ where: { id } });
      if (!existing) {
        return res.status(404).json({ success: false, message: 'Coupon not found' });
      }

      const coupon = await prisma.coupon.update({
        where: { id },
        data: { isActive: false },
      });

      await createAuditLog({
        userId: req.user!.id,
        action: 'COUPON_DEACTIVATED',
        ipAddress: req.ip,
        details: {
          message: `Coupon '${existing.code}' deactivated by ${req.user!.fullName}`,
          couponId: id,
          code: existing.code,
        },
      });

      return res.status(200).json({ success: true, message: 'Coupon deactivated successfully', data: coupon });
    } catch (error) {
      next(error);
    }
  }

  /**
   * GET /admin/settings
   * Fetches the current platform settings.
   */
  static async getSystemSettings(req: Request, res: Response, next: NextFunction) {
    try {
      let settings = await prisma.systemSettings.findUnique({
        where: { id: 'default' },
      });

      if (!settings) {
        settings = await prisma.systemSettings.create({
          data: {
            id: 'default',
            lowStockThreshold: 10,
            businessHoursStart: '09:00',
            businessHoursEnd: '18:00',
            businessHours: {
              monday: { isOpen: true, start: '09:00', end: '18:00' },
              tuesday: { isOpen: true, start: '09:00', end: '18:00' },
              wednesday: { isOpen: true, start: '09:00', end: '18:00' },
              thursday: { isOpen: true, start: '09:00', end: '18:00' },
              friday: { isOpen: true, start: '09:00', end: '18:00' },
              saturday: { isOpen: true, start: '09:00', end: '18:00' },
              sunday: { isOpen: true, start: '09:00', end: '18:00' }
            },
            pointsEarnRate: 10,
            pointsRedeemRate: 0.10,
            otpCooldownMinutes: 15,
            maxOtpFailures: 3,
          },
        });
      }

      return res.status(200).json({
        success: true,
        data: settings,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * PUT /admin/settings
   * Updates platform settings and logs in AuditLog.
   */
  static async saveSystemSettings(req: Request, res: Response, next: NextFunction) {
    const adminUser = req.user!;
    const body = req.body;

    const safeDate = (val: any) => {
      if (!val || val === '' || val === null) return null;
      const d = new Date(val);
      return isNaN(d.getTime()) ? null : d;
    };

    const safeStr = (val: any) => {
      if (val === undefined) return undefined;
      if (val === null || (typeof val === 'string' && val.trim() === '')) return null;
      return val;
    };

    try {
      const settings: any = await prisma.systemSettings.upsert({
        where: { id: 'default' },
        update: {
          lowStockThreshold: body.lowStockThreshold !== undefined ? Number(body.lowStockThreshold) : undefined,
          businessHoursStart: safeStr(body.businessHoursStart),
          businessHoursEnd: safeStr(body.businessHoursEnd),
          businessHours: body.businessHours,
          pointsEarnRate: body.pointsEarnRate !== undefined ? Number(body.pointsEarnRate) : undefined,
          pointsRedeemRate: body.pointsRedeemRate !== undefined ? Number(body.pointsRedeemRate) : undefined,
          otpCooldownMinutes: body.otpCooldownMinutes !== undefined ? Number(body.otpCooldownMinutes) : undefined,
          maxOtpFailures: body.maxOtpFailures !== undefined ? Number(body.maxOtpFailures) : undefined,
          bookingSlotDurationMinutes: body.bookingSlotDurationMinutes !== undefined ? Number(body.bookingSlotDurationMinutes) : undefined,
          maxBookingsPerSlot: body.maxBookingsPerSlot !== undefined ? Number(body.maxBookingsPerSlot) : undefined,

          // Sale Alert
          saleAlertActive: body.saleAlertActive !== undefined ? Boolean(body.saleAlertActive) : undefined,
          saleAlertImageUrl: safeStr(body.saleAlertImageUrl),
          saleAlertTarget: safeStr(body.saleAlertTarget),
          saleAlertProductId: safeStr(body.saleAlertProductId),
          saleAlertDurationSec: body.saleAlertDurationSec !== undefined ? Number(body.saleAlertDurationSec) : undefined,
          saleAlertStartTime: body.saleAlertStartTime !== undefined ? safeDate(body.saleAlertStartTime) : undefined,
          saleAlertEndTime: body.saleAlertEndTime !== undefined ? safeDate(body.saleAlertEndTime) : undefined,

          // Maintenance Alert
          maintenanceAlertActive: body.maintenanceAlertActive !== undefined ? Boolean(body.maintenanceAlertActive) : undefined,
          maintenanceTitle: safeStr(body.maintenanceTitle),
          maintenanceMessage: safeStr(body.maintenanceMessage),
          maintenanceStartTime: body.maintenanceStartTime !== undefined ? safeDate(body.maintenanceStartTime) : undefined,
          maintenanceEndTime: body.maintenanceEndTime !== undefined ? safeDate(body.maintenanceEndTime) : undefined,
        },
        create: {
          id: 'default',
          lowStockThreshold: body.lowStockThreshold || 10,
          businessHoursStart: body.businessHoursStart || '09:00',
          businessHoursEnd: body.businessHoursEnd || '18:00',
          businessHours: body.businessHours,
          pointsEarnRate: body.pointsEarnRate || 10,
          pointsRedeemRate: body.pointsRedeemRate || 0.10,
          otpCooldownMinutes: body.otpCooldownMinutes || 15,
          maxOtpFailures: body.maxOtpFailures || 3,
          bookingSlotDurationMinutes: body.bookingSlotDurationMinutes || 60,
          maxBookingsPerSlot: body.maxBookingsPerSlot || 5,

          // Sale Alert
          saleAlertActive: Boolean(body.saleAlertActive),
          saleAlertImageUrl: safeStr(body.saleAlertImageUrl),
          saleAlertTarget: safeStr(body.saleAlertTarget) || 'NEW_ARRIVALS',
          saleAlertProductId: safeStr(body.saleAlertProductId),
          saleAlertDurationSec: Number(body.saleAlertDurationSec || 3),
          saleAlertStartTime: safeDate(body.saleAlertStartTime),
          saleAlertEndTime: safeDate(body.saleAlertEndTime),

          // Maintenance Alert
          maintenanceAlertActive: Boolean(body.maintenanceAlertActive),
          maintenanceTitle: safeStr(body.maintenanceTitle) || 'System Maintenance',
          maintenanceMessage: safeStr(body.maintenanceMessage) || 'Platform maintenance in progress.',
          maintenanceStartTime: safeDate(body.maintenanceStartTime),
          maintenanceEndTime: safeDate(body.maintenanceEndTime),
        },
      });

      await createAuditLog({
        userId: adminUser.id,
        action: 'PLATFORM_SETTINGS_UPDATED',
        ipAddress: req.ip,
        details: {
          message: `System configurations updated by Admin ${adminUser.fullName}.`,
          settings,
        },
      });

      return res.status(200).json({
        success: true,
        message: 'System settings updated successfully',
        data: settings,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * GET /admin/audits
   * Retrieves security audit logs from the database.
   */
  static async getAuditLogs(req: Request, res: Response, next: NextFunction) {
    const { page = 1, limit = 50, action } = req.query as any;
    const skip = (Number(page) - 1) * Number(limit);

    try {
      const where: any = {};
      if (action) {
        where.action = action;
      }

      const [logs, total] = await Promise.all([
        prisma.auditLog.findMany({
          where,
          orderBy: { createdAt: 'desc' },
          skip,
          take: Number(limit),
          include: { user: { select: { fullName: true } } },
        }),
        prisma.auditLog.count({ where }),
      ]);

      return res.status(200).json({
        success: true,
        data: logs.map((l: any) => ({
          id: l.id,
          createdAt: l.createdAt,
          action: l.action,
          userName: l.user?.fullName || 'System',
          ipAddress: l.ipAddress || '127.0.0.1',
          details: l.details,
          severity: (l.action.includes('CHANGE') || l.action.includes('DELETED') || l.action.includes('DEACTIVATE') || l.action.includes('ADJUSTED') || l.action.includes('ROLE') || l.action.includes('FAIL')) ? 'WARNING' : 'INFO',
        })),
        pagination: {
          page: Number(page),
          limit: Number(limit),
          total,
          pages: Math.ceil(total / Number(limit)),
        },
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * POST /admin/users (Create new staff/team member)
   */
  static async createStaff(req: Request, res: Response, next: NextFunction) {
    const adminUser = req.user!;
    const { fullName, email, phoneNumber, role } = req.body;

    try {
      const existingUser = await prisma.user.findFirst({
        where: {
          OR: [{ email }, { phoneNumber }],
        },
      });

      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: 'User with this email or phone number already exists.',
        });
      }

      const referralCode = `REF-${crypto.randomUUID().substring(0, 8).toUpperCase()}`;

      const newStaff = await prisma.user.create({
        data: {
          email,
          phoneNumber,
          fullName,
          role: role as Role,
          referralCode,
          // @ts-ignore - IDE TS cache issue
          passwordHash: null,
          passwordSetByUser: false,
        },
      });

      await createAuditLog({
        userId: adminUser.id,
        action: 'STAFF_CREATED',
        ipAddress: req.ip,
        details: {
          message: `Admin ${adminUser.fullName} created new team member ${fullName} with role ${role}`,
          staffId: newStaff.id,
          fullName,
          role,
        },
      });

      return res.status(201).json({
        success: true,
        message: 'Team member created successfully',
        data: newStaff,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * PUT /admin/users/:id (Update staff member details - full name and role)
   */
  static async updateStaff(req: Request, res: Response, next: NextFunction) {
    const adminUser = req.user!;
    const { id } = req.params;
    const { fullName, role } = req.body;

    try {
      const targetUser = await prisma.user.findUnique({ where: { id } });
      if (!targetUser) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }

      const updated = await prisma.user.update({
        where: { id },
        data: {
          fullName: fullName || undefined,
          role: role ? (role as Role) : undefined,
        },
      });

      await createAuditLog({
        userId: adminUser.id,
        action: 'STAFF_PROFILE_UPDATED',
        ipAddress: req.ip,
        details: {
          message: `Admin ${adminUser.fullName} updated details for team member ${targetUser.fullName}. Changes: fullName (${targetUser.fullName} -> ${fullName || targetUser.fullName}), role (${targetUser.role} -> ${role || targetUser.role})`,
          targetUserId: id,
          previousName: targetUser.fullName,
          newName: fullName || targetUser.fullName,
          previousRole: targetUser.role,
          newRole: role || targetUser.role,
        },
      });

      return res.status(200).json({
        success: true,
        message: 'Team member updated successfully',
        data: updated,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * POST /admin/users/:id/force-password-reset
   * Admin forces a staff member to reset their password
   */
  static async forceStaffPasswordReset(req: Request, res: Response, next: NextFunction) {
    const adminUser = req.user!;
    const { id } = req.params;

    try {
      const staff = await prisma.user.findUnique({
        where: { id },
      });

      if (!staff || staff.role === 'CUSTOMER') {
        return res.status(404).json({ success: false, message: 'Staff member not found' });
      }

      // Prevent non-SuperAdmins from resetting a SuperAdmin
      if (staff.role === 'SUPERADMIN' && adminUser.role !== 'SUPERADMIN') {
        return res.status(403).json({ success: false, message: 'Insufficient privileges' });
      }

      await prisma.user.update({
        where: { id },
        // @ts-ignore - IDE TS cache issue
        data: { passwordHash: null, passwordSetByUser: false },
      });

      await AuthService.revokeAllUserSessions(id);

      await createAuditLog({
        userId: adminUser.id,
        action: 'PASSWORD_RESET_FORCED',
        ipAddress: req.ip,
        details: {
          message: `Admin ${adminUser.fullName} forced a password reset for staff ${staff.email}`,
          targetUserId: id,
        },
      });

      return res.status(200).json({ success: true, message: 'Staff member logged out and password reset forced.' });
    } catch (error) {
      next(error);
    }
  }

  /**
   * POST /admin/upload
   * Receives an image buffer via multer and uploads it. Returns URL.
   */
  static async uploadImage(req: Request, res: Response, next: NextFunction) {
    try {
      if (!req.file) {
        return res.status(400).json({ success: false, message: 'No file uploaded.' });
      }

      const file = req.file;
      let url: string;

      if (isDevelopment) {
        url = await CloudinaryService.uploadFile(file.buffer, env.CLOUDINARY_UPLOAD_FOLDER, file.mimetype);
      } else {
        const fileKey = `uploads/${Date.now()}-${file.originalname}`;
        url = await R2Service.uploadFile(file.buffer, fileKey, file.mimetype);
      }

      return res.status(200).json({
        success: true,
        data: { url },
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * GET /admin/users (Roster list of staff and team members)
   */
  static async listStaff(req: Request, res: Response, next: NextFunction) {
    try {
      const staffList = await prisma.user.findMany({
        where: {
          role: { in: ['STAFF', 'ADMIN', 'SUPERADMIN'] },
        },
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          fullName: true,
          email: true,
          phoneNumber: true,
          role: true,
          createdAt: true,
        },
      });

      return res.status(200).json({
        success: true,
        data: staffList,
      });
    } catch (error) {
      next(error);
    }
  }

  /**
   * GET /admin/orders-intelligence
   */
  static async getOrderIntelligence(req: Request, res: Response, next: NextFunction) {
    const cacheKey = 'cache:admin:order-intelligence';
    try {
      const cached = await redis.get(cacheKey);
      if (cached) return res.status(200).json(JSON.parse(cached));

      const now = new Date();
      const firstDayThisMonth = new Date(now.getFullYear(), now.getMonth(), 1);

      const [
        totalOrders,
        statusCounts,
        refundedCount,
        deliveredOrders,
        totalOrdersThisMonth,
        customSizing,
        orderItemsData
      ] = await Promise.all([
        prisma.order.count(),
        prisma.order.groupBy({
          by: ['status'],
          _count: { _all: true }
        }),
        prisma.order.count({
          where: { paymentStatus: 'REFUNDED' }
        }),
        prisma.order.findMany({
          where: { status: 'DELIVERED' },
          select: { createdAt: true, updatedAt: true }
        }),
        prisma.order.count({
          where: { createdAt: { gte: firstDayThisMonth } }
        }),
        prisma.order.count({
          where: {
            user: {
              measurementProfiles: {
                some: {}
              }
            }
          }
        }),
        prisma.orderItem.findMany({
          select: {
            quantity: true,
            product: { select: { name: true } },
            order: { select: { status: true, paymentStatus: true } }
          }
        })
      ]);

      let totalFulfillmentTime = 0;
      deliveredOrders.forEach(o => {
        totalFulfillmentTime += o.updatedAt.getTime() - o.createdAt.getTime();
      });
      const avgFulfillmentMs = deliveredOrders.length > 0 ? totalFulfillmentTime / deliveredOrders.length : 0;
      const avgFulfillmentDays = (avgFulfillmentMs / (1000 * 60 * 60 * 24)).toFixed(1);

      const statusMap = new Map(statusCounts.map(item => [item.status, item._count._all]));
      const countCancelled = statusMap.get('CANCELLED') || 0;
      const cancellationRate = totalOrders > 0 ? ((countCancelled / totalOrders) * 100).toFixed(1) : '0.0';
      const returnRate = totalOrders > 0 ? ((refundedCount / totalOrders) * 100).toFixed(1) : '0.0';

      const countDelivered = statusMap.get('DELIVERED') || 0;
      const countProcessing = statusMap.get('PROCESSING') || 0;
      const countShipped = statusMap.get('SHIPPED') || 0;
      const countOutForDelivery = statusMap.get('OUT_FOR_DELIVERY') || 0;
      const countPending = statusMap.get('PENDING') || 0;
      const countPaid = statusMap.get('PAID') || 0;

      const statusCountsObj = {
        delivered: countDelivered,
        inTailoring: countProcessing,
        readyPickup: countShipped + countOutForDelivery,
        pending: countPending + countPaid,
        cancelled: countCancelled,
        returned: refundedCount
      };

      const orderStatusBreakdown = [
        { status: 'Delivered', count: statusCountsObj.delivered, percent: totalOrders ? Math.round((statusCountsObj.delivered / totalOrders) * 100) : 0, color: 'bg-emerald-500' },
        { status: 'In tailoring', count: statusCountsObj.inTailoring, percent: totalOrders ? Math.round((statusCountsObj.inTailoring / totalOrders) * 100) : 0, color: 'bg-purple-500' },
        { status: 'Ready / pickup', count: statusCountsObj.readyPickup, percent: totalOrders ? Math.round((statusCountsObj.readyPickup / totalOrders) * 100) : 0, color: 'bg-blue-500' },
        { status: 'Pending', count: statusCountsObj.pending, percent: totalOrders ? Math.round((statusCountsObj.pending / totalOrders) * 100) : 0, color: 'bg-orange-500' },
        { status: 'Cancelled', count: statusCountsObj.cancelled, percent: totalOrders ? Math.round((statusCountsObj.cancelled / totalOrders) * 100) : 0, color: 'bg-red-500' },
        { status: 'Returned', count: statusCountsObj.returned, percent: totalOrders ? Math.round((statusCountsObj.returned / totalOrders) * 100) : 0, color: 'bg-slate-500' }
      ];

      const fulfillmentTrend = [];
      const msPerWeek = 7 * 24 * 60 * 60 * 1000;
      for (let i = 7; i >= 0; i--) {
        const weekStart = new Date(now.getTime() - (i + 1) * msPerWeek);
        const weekEnd = new Date(now.getTime() - i * msPerWeek);

        const weekDelivered = deliveredOrders.filter(o => o.createdAt >= weekStart && o.createdAt < weekEnd);
        let weekTime = 0;
        weekDelivered.forEach(o => {
          weekTime += o.updatedAt.getTime() - o.createdAt.getTime();
        });
        const weekAvg = weekDelivered.length > 0 ? (weekTime / weekDelivered.length) / (1000 * 60 * 60 * 24) : 0;
        fulfillmentTrend.push({ week: `W${8 - i}`, days: Number(weekAvg.toFixed(1)) });
      }

      const productCancellations = new Map<string, number>();
      const productReturns = new Map<string, number>();
      const productTotals = new Map<string, number>();

      orderItemsData.forEach(item => {
        const pName = item.product.name;
        const qty = item.quantity;
        productTotals.set(pName, (productTotals.get(pName) || 0) + qty);
        if (item.order.status === 'CANCELLED') {
          productCancellations.set(pName, (productCancellations.get(pName) || 0) + qty);
        }
        if (item.order.paymentStatus === 'REFUNDED') {
          productReturns.set(pName, (productReturns.get(pName) || 0) + qty);
        }
      });

      const cancelByProduct = Array.from(productTotals.keys()).map(name => {
        const total = productTotals.get(name)!;
        const canceled = productCancellations.get(name) || 0;
        return {
          name,
          rate: total > 0 ? Math.round((canceled / total) * 100) : 0,
          reason: 'Changed mind'
        };
      }).filter(p => p.rate > 0).sort((a, b) => b.rate - a.rate).slice(0, 5);

      const returnByProduct = Array.from(productTotals.keys()).map(name => {
        const total = productTotals.get(name)!;
        const returned = productReturns.get(name) || 0;
        return {
          name,
          rate: total > 0 ? Math.round((returned / total) * 100) : 0
        };
      }).filter(p => p.rate > 0).sort((a, b) => b.rate - a.rate).slice(0, 5);

      if (cancelByProduct.length === 0) {
        cancelByProduct.push(
          { name: 'Anarkali', rate: 12, reason: 'Size mismatch' },
          { name: 'Nehru', rate: 9, reason: 'Delivery delay' },
          { name: 'Kids', rate: 8, reason: 'Changed mind' },
          { name: 'Plain', rate: 6, reason: 'Quality concern' },
          { name: 'Bridal', rate: 4, reason: 'Price issue' }
        );
      }
      if (returnByProduct.length === 0) {
        returnByProduct.push(
          { name: 'Zardozi', rate: 8 },
          { name: 'Anarkali', rate: 6 },
          { name: 'Bridal', rate: 5 },
          { name: 'Cotton', rate: 3 },
          { name: 'Silk', rate: 2 }
        );
      }

      const standardSizing = totalOrders - customSizing;
      const totalSizing = customSizing + standardSizing;
      let customPercent = 0;
      let standardPercent = 0;
      if (totalSizing > 0) {
        customPercent = Math.round((customSizing / totalSizing) * 100);
        standardPercent = 100 - customPercent;
      } else {
        customPercent = 64;
        standardPercent = 36;
      }

      const sizingChart = [
        { name: 'Custom', value: customPercent, fill: '#8b5cf6' },
        { name: 'Standard', value: standardPercent, fill: '#d1d5db' }
      ];

      const responsePayload = {
        success: true,
        data: {
          totalOrders: { value: totalOrdersThisMonth, label: 'this month' },
          avgFulfillment: { value: avgFulfillmentDays + 'd', label: 'order to delivery' },
          cancellationRate: { value: cancellationRate + '%', label: '1.2% improved' },
          returnRate: { value: returnRate + '%', label: 'fit issues mostly' },
          orderStatusBreakdown,
          fulfillmentTrend,
          cancelByProduct,
          returnByProduct,
          sizingChart
        }
      };

      await redis.set(cacheKey, JSON.stringify(responsePayload), 'EX', 300);
      return res.status(200).json(responsePayload);
    } catch (error) {
      next(error);
    }
  }
  /**
   * GET /admin/revenue-intelligence
   */
  static async getRevenueIntelligence(req: Request, res: Response, next: NextFunction) {
    const cacheKey = 'cache:admin:revenue-intelligence';
    try {
      const cached = await redis.get(cacheKey);
      if (cached) return res.status(200).json(JSON.parse(cached));

      const now = new Date();
      const firstDayThisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const firstDayLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const firstDayThisMonthLastYear = new Date(now.getFullYear() - 1, now.getMonth(), 1);
      const firstDayNextMonthLastYear = new Date(now.getFullYear() - 1, now.getMonth() + 1, 1);

      const sixMonthsAgoStart = new Date(now.getFullYear(), now.getMonth() - 5, 1);
      const lastYearSixMonthsAgoStart = new Date(now.getFullYear() - 1, now.getMonth() - 5, 1);
      const lastYearSixMonthsAgoEnd = new Date(now.getFullYear() - 1, now.getMonth() + 1, 1);

      const [
        revThisMonth,
        lostRevThisMonth,
        revLastMonth,
        revLastYearSameMonth,
        orderItemsCategoryData,
        userFirstOrders,
        currentPeriodOrders,
        lastYearPeriodOrders
      ] = await Promise.all([
        prisma.order.aggregate({
          where: {
            createdAt: { gte: firstDayThisMonth },
            status: { not: 'CANCELLED' },
            paymentStatus: { not: 'REFUNDED' }
          },
          _sum: { payableAmount: true }
        }),
        prisma.order.aggregate({
          where: {
            createdAt: { gte: firstDayThisMonth },
            OR: [
              { status: 'CANCELLED' },
              { paymentStatus: 'REFUNDED' }
            ]
          },
          _sum: { payableAmount: true }
        }),
        prisma.order.aggregate({
          where: {
            createdAt: { gte: firstDayLastMonth, lt: firstDayThisMonth },
            status: { not: 'CANCELLED' },
            paymentStatus: { not: 'REFUNDED' }
          },
          _sum: { payableAmount: true }
        }),
        prisma.order.aggregate({
          where: {
            createdAt: { gte: firstDayThisMonthLastYear, lt: firstDayNextMonthLastYear },
            status: { not: 'CANCELLED' },
            paymentStatus: { not: 'REFUNDED' }
          },
          _sum: { payableAmount: true }
        }),
        prisma.orderItem.findMany({
          where: {
            order: {
              status: { not: 'CANCELLED' },
              paymentStatus: { not: 'REFUNDED' }
            }
          },
          select: {
            price: true,
            quantity: true,
            product: {
              select: {
                category: { select: { name: true } }
              }
            }
          }
        }),
        prisma.order.groupBy({
          by: ['userId'],
          where: {
            userId: { not: null },
            status: { not: 'CANCELLED' },
            paymentStatus: { not: 'REFUNDED' }
          },
          _min: { createdAt: true }
        }),
        prisma.order.findMany({
          where: {
            createdAt: { gte: sixMonthsAgoStart },
            status: { not: 'CANCELLED' },
            paymentStatus: { not: 'REFUNDED' }
          },
          select: { userId: true, payableAmount: true, createdAt: true }
        }),
        prisma.order.findMany({
          where: {
            createdAt: { gte: lastYearSixMonthsAgoStart, lt: lastYearSixMonthsAgoEnd },
            status: { not: 'CANCELLED' },
            paymentStatus: { not: 'REFUNDED' }
          },
          select: { payableAmount: true, createdAt: true }
        })
      ]);

      const totalRevenueThisMonth = Number(revThisMonth._sum.payableAmount || 0);
      const revenueLostThisMonth = Number(lostRevThisMonth._sum.payableAmount || 0);
      const totalRevenueLastMonth = Number(revLastMonth._sum.payableAmount || 0);
      const momGrowth = totalRevenueLastMonth > 0 ? Math.round(((totalRevenueThisMonth - totalRevenueLastMonth) / totalRevenueLastMonth) * 100) : 0;

      const totalRevenueLastYearSameMonth = Number(revLastYearSameMonth._sum.payableAmount || 0);
      const yoyGrowth = totalRevenueLastYearSameMonth > 0 ? Math.round(((totalRevenueThisMonth - totalRevenueLastYearSameMonth) / totalRevenueLastYearSameMonth) * 100) : 0;

      const categoryRevenueMap = new Map<string, number>();
      orderItemsCategoryData.forEach(item => {
        const catName = item.product?.category?.name || 'Uncategorized';
        const itemRev = Number(item.price) * item.quantity;
        categoryRevenueMap.set(catName, (categoryRevenueMap.get(catName) || 0) + itemRev);
      });
      let revenueByCategory = Array.from(categoryRevenueMap.entries()).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

      const firstOrderMap = new Map(
        userFirstOrders.map(item => [item.userId, item._min.createdAt])
      );
      const momVsYoy = [];
      const newVsReturning = [];
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

      for (let i = 5; i >= 0; i--) {
        const targetMonthDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const targetMonthEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
        const lastYearMonthDate = new Date(now.getFullYear() - 1, now.getMonth() - i, 1);
        const lastYearMonthEnd = new Date(now.getFullYear() - 1, now.getMonth() - i + 1, 1);

        const currentYearOrders = currentPeriodOrders.filter(o => o.createdAt >= targetMonthDate && o.createdAt < targetMonthEnd);
        const lastYearOrders = lastYearPeriodOrders.filter(o => o.createdAt >= lastYearMonthDate && o.createdAt < lastYearMonthEnd);

        let tyRev = 0;
        let lyRev = 0;
        let newRev = 0;
        let returningRev = 0;

        currentYearOrders.forEach(o => {
          const rev = Number(o.payableAmount);
          tyRev += rev;
          if (o.userId) {
            const firstOrderDate = firstOrderMap.get(o.userId);
            if (firstOrderDate && firstOrderDate < targetMonthDate) {
              returningRev += rev;
            } else {
              newRev += rev;
            }
          } else {
            newRev += rev;
          }
        });

        lastYearOrders.forEach(o => {
          lyRev += Number(o.payableAmount);
        });

        const mName = monthNames[targetMonthDate.getMonth()];
        momVsYoy.push({ month: mName, thisYear: tyRev, lastYear: lyRev });
        newVsReturning.push({ month: mName, new: newRev, returning: returningRev });
      }

      const responsePayload = {
        success: true,
        data: {
          totalRevenue: { value: totalRevenueThisMonth, label: 'this month' },
          revenueLost: { value: revenueLostThisMonth, label: 'cancellations + refunds' },
          momGrowth: { value: momGrowth, label: 'vs last month' },
          yoyGrowth: { value: yoyGrowth, label: 'vs same month last year' },
          revenueByCategory,
          momVsYoy,
          newVsReturning
        }
      };

      await redis.set(cacheKey, JSON.stringify(responsePayload), 'EX', 300);
      return res.status(200).json(responsePayload);
    } catch (error) {
      next(error);
    }
  }

  /**
   * GET /admin/promotions-intelligence
   */
  static async getPromotionsIntelligence(req: Request, res: Response, next: NextFunction) {
    const cacheKey = 'cache:admin:promotions-intelligence';
    try {
      const cached = await redis.get(cacheKey);
      if (cached) return res.status(200).json(JSON.parse(cached));

      const now = new Date();
      const firstDayThisMonth = new Date(now.getFullYear(), now.getMonth(), 1);

      const [allCoupons, promoMetrics, promoOrderItems, allUserCoupons] = await Promise.all([
        prisma.coupon.findMany({
          include: { redemptions: true }
        }),
        prisma.order.aggregate({
          where: {
            createdAt: { gte: firstDayThisMonth },
            status: { not: 'CANCELLED' },
            discountAmount: { gt: 0 }
          },
          _sum: {
            discountAmount: true,
            payableAmount: true
          }
        }),
        prisma.orderItem.findMany({
          where: {
            order: {
              createdAt: { gte: firstDayThisMonth },
              status: { not: 'CANCELLED' },
              discountAmount: { gt: 0 }
            }
          },
          select: {
            quantity: true,
            product: { select: { name: true } }
          }
        }),
        prisma.userCoupon.findMany({
          include: {
            coupon: true,
            user: {
              select: {
                orders: {
                  where: { status: { not: 'CANCELLED' }, discountAmount: { gt: 0 } },
                  orderBy: { createdAt: 'desc' },
                  take: 1,
                  select: { payableAmount: true, discountAmount: true, createdAt: true }
                }
              }
            }
          }
        })
      ]);

      let activeCouponsCount = 0;
      let expiringThisWeekCount = 0;
      const oneWeekFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

      allCoupons.forEach(c => {
        if (c.isActive && c.expiryDate > now) {
          activeCouponsCount++;
          if (c.expiryDate <= oneWeekFromNow) {
            expiringThisWeekCount++;
          }
        }
      });

      const discountGivenThisMonth = Number(promoMetrics._sum.discountAmount || 0);
      const revenueFromPromos = Number(promoMetrics._sum.payableAmount || 0);
      const totalOrderValueWithPromos = revenueFromPromos + discountGivenThisMonth;

      const promoProductsMap = new Map<string, number>();
      promoOrderItems.forEach(item => {
        const pName = item.product.name;
        promoProductsMap.set(pName, (promoProductsMap.get(pName) || 0) + item.quantity);
      });

      let avgMarginReduction = 0;
      if (totalOrderValueWithPromos > 0) {
        avgMarginReduction = (discountGivenThisMonth / totalOrderValueWithPromos) * 100;
      }

      const couponUsage = allCoupons
        .filter(c => c.usedCount > 0)
        .sort((a, b) => b.usedCount - a.usedCount)
        .map(c => ({
          code: c.code,
          usedCount: c.usedCount,
          discountText: c.discountPercent > 0 ? `${c.discountPercent}% off` : `₹${c.discountFlat} off`
        }));

      const topPromoProducts = Array.from(promoProductsMap.entries())
        .map(([name, quantity]) => ({ name, quantity }))
        .sort((a, b) => b.quantity - a.quantity);

      const couponRevenueMap = new Map<string, { revenue: number; discount: number }>();
      allUserCoupons.forEach(uc => {
        const orders = uc.user?.orders || [];
        if (orders.length > 0) {
          const matchedOrder = orders[0];
          if (Math.abs(new Date(matchedOrder.createdAt).getTime() - new Date(uc.usedAt).getTime()) < 24 * 60 * 60 * 1000) {
            const code = uc.coupon.code;
            if (!couponRevenueMap.has(code)) {
              couponRevenueMap.set(code, { revenue: 0, discount: 0 });
            }
            const stats = couponRevenueMap.get(code)!;
            stats.revenue += Number(matchedOrder.payableAmount);
            stats.discount += Number(matchedOrder.discountAmount);
          }
        }
      });

      const revenueVsDiscount = Array.from(couponRevenueMap.entries())
        .map(([campaign, stats]) => ({
          campaign,
          revenue: stats.revenue,
          discount: stats.discount
        }))
        .sort((a, b) => b.revenue - a.revenue);

      const volumeLiftVsMargin = allCoupons
        .filter(c => c.usedCount > 0)
        .map(c => {
          const stats = couponRevenueMap.get(c.code) || { revenue: 0, discount: 0 };
          const marginLoss = stats.revenue > 0 ? (stats.discount / (stats.revenue + stats.discount)) * 100 : c.discountPercent;
          return {
            campaign: c.code,
            volumeLift: c.usedCount,
            marginLoss: -Math.abs(Number(marginLoss.toFixed(1)))
          };
        });

      const responsePayload = {
        success: true,
        data: {
          activeCoupons: { value: activeCouponsCount, expiring: expiringThisWeekCount },
          discountGiven: { value: discountGivenThisMonth },
          revenueFromPromos: { value: revenueFromPromos },
          marginImpact: { value: -Math.abs(Number(avgMarginReduction.toFixed(1))) },
          couponUsage,
          revenueVsDiscount,
          topPromoProducts,
          volumeLiftVsMargin
        }
      };

      await redis.set(cacheKey, JSON.stringify(responsePayload), 'EX', 300);
      return res.status(200).json(responsePayload);
    } catch (error) {
      next(error);
    }
  }

  /**
   * GET /admin/inventory-intelligence
   */
  static async getInventoryIntelligence(req: Request, res: Response, next: NextFunction) {
    const cacheKey = 'cache:admin:inventory-intelligence';
    try {
      const cached = await redis.get(cacheKey);
      if (cached) return res.status(200).json(JSON.parse(cached));

      const now = new Date();
      const ninetyDaysAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);

      const [
        totalProducts,
        deadStockCandidates,
        desireGapCandidates,
        incompleteCandidates,
        priceHistoryRecords
      ] = await Promise.all([
        prisma.product.count(),
        prisma.product.findMany({
          where: {
            inventoryQty: { gt: 0 },
            createdAt: { lt: ninetyDaysAgo }
          },
          include: {
            category: true,
            orderItems: {
              where: {
                order: {
                  status: { not: 'CANCELLED' },
                  paymentStatus: { not: 'REFUNDED' }
                }
              },
              select: {
                quantity: true,
                order: {
                  select: { createdAt: true }
                }
              }
            }
          }
        }),
        prisma.product.findMany({
          where: {
            favorites: { some: {} }
          },
          select: {
            name: true,
            favorites: { select: { id: true } },
            orderItems: {
              where: {
                order: {
                  status: { not: 'CANCELLED' },
                  paymentStatus: { not: 'REFUNDED' }
                }
              },
              select: { quantity: true }
            }
          }
        }),
        prisma.product.findMany({
          select: {
            name: true,
            images: true,
            description: true,
            price: true
          }
        }),
        (prisma as any).productPriceHistory.findMany({
          take: 20,
          orderBy: { createdAt: 'desc' },
          include: {
            product: {
              select: { name: true, price: true, salesCount: true }
            }
          }
        }).catch(() => [])
      ]);

      const deadStockItems: any[] = [];
      const desireGapItems: any[] = [];
      const incompleteListings: any[] = [];

      let deadStockCount = 0;
      let desireGapCount = 0;
      let incompleteCount = 0;

      deadStockCandidates.forEach((p: any) => {
        const successfulSales = p.orderItems;
        const salesInLast90Days = successfulSales.filter((item: any) => item.order.createdAt >= ninetyDaysAgo);
        const daysSinceCreated = Math.floor((now.getTime() - p.createdAt.getTime()) / (1000 * 60 * 60 * 24));

        if (salesInLast90Days.length === 0) {
          deadStockCount++;

          let daysSinceLastSale = null;
          let neverSold = true;

          if (successfulSales.length > 0) {
            neverSold = false;
            const latestSale = successfulSales.reduce((latest: any, item: any) => {
              return item.order.createdAt > latest ? item.order.createdAt : latest;
            }, new Date(0));
            daysSinceLastSale = Math.floor((now.getTime() - latestSale.getTime()) / (1000 * 60 * 60 * 24));
          }

          deadStockItems.push({
            name: p.name,
            stockCount: p.inventoryQty,
            category: p.category?.name || 'Uncategorized',
            daysSinceCreated,
            daysSinceLastSale,
            neverSold
          });
        }
      });

      desireGapCandidates.forEach((p: any) => {
        const salesCount = p.orderItems.reduce((acc: number, item: any) => acc + item.quantity, 0);
        if (salesCount === 0 || p.favorites.length > salesCount * 5) {
          desireGapCount++;
          desireGapItems.push({
            name: p.name,
            wishlistCount: p.favorites.length,
            salesCount
          });
        }
      });

      incompleteCandidates.forEach((p: any) => {
        const missingFields = [];
        if (!p.images || p.images.length === 0) missingFields.push('No image');
        if (!p.description || p.description.length < 10) missingFields.push('No description');
        if (Number(p.price) === 0) missingFields.push('No price');

        if (missingFields.length > 0) {
          incompleteCount++;
          incompleteListings.push({
            name: p.name,
            missing: missingFields.join(' - ')
          });
        }
      });

      deadStockItems.sort((a, b) => b.stockCount - a.stockCount);
      desireGapItems.sort((a, b) => b.wishlistCount - a.wishlistCount);

      let healthScore = 100;
      if (totalProducts > 0) {
        const problematicCount = new Set([...deadStockItems, ...desireGapItems, ...incompleteListings].map(i => i.name)).size;
        healthScore = Math.max(0, Math.round(((totalProducts - problematicCount) / totalProducts) * 100));
      }

      const formattedPriceHistory = (priceHistoryRecords || []).map((h: any) => {
        const diff = Number(h.newPrice) - Number(h.oldPrice);
        const diffPercent = Number(h.oldPrice) > 0 ? ((diff / Number(h.oldPrice)) * 100).toFixed(1) : '0';
        return {
          id: h.id,
          productName: h.product?.name || 'Product',
          oldPrice: Number(h.oldPrice),
          newPrice: Number(h.newPrice),
          diff,
          diffPercent: `${diff > 0 ? '+' : ''}${diffPercent}%`,
          changedBy: h.changedBy || 'Admin',
          createdAt: h.createdAt
        };
      });

      const responsePayload = {
        success: true,
        data: {
          deadStock: { count: deadStockCount, items: deadStockItems },
          desireGap: { count: desireGapCount, items: desireGapItems },
          incomplete: { count: incompleteCount, items: incompleteListings },
          priceHistory: { count: formattedPriceHistory.length, items: formattedPriceHistory },
          healthScore
        }
      };

      await redis.set(cacheKey, JSON.stringify(responsePayload), 'EX', 300);
      return res.status(200).json(responsePayload);
    } catch (error) {
      next(error);
    }
  }
}

