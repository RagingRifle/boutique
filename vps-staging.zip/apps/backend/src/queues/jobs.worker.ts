import { Worker, Job } from 'bullmq';
import { connectionOptions, QUEUE_NAME } from './queue.config.js';
import env from '../config/env.js';
import prisma from '../config/db.js';
import logger from '../utils/logger.js';
import PdfService from '../services/pdf.service.js';
import R2Service from '../services/r2.service.js';
import EmailService from '../services/email.service.js';
import SmsService from '../services/sms.service.js';
import NotificationService from '../services/notification.service.js';
import JobsProducer from './jobs.producer.js';
import { getIO } from '../socket/socket.handler.js';
import { isDevelopment } from '../config/environment.js';

let worker: Worker;

export function initWorker() {
  const hasRealRedis = env.REDIS_URL && !env.REDIS_URL.includes('localhost') && !env.REDIS_URL.includes('127.0.0.1');
  if (isDevelopment || !hasRealRedis) {
    logger.info('BullMQ Background Worker disabled (no external Redis configured).');
    return;
  }
  worker = new Worker(
    QUEUE_NAME,
    async (job: Job) => {
      logger.info(`Starting job: ${job.name} (ID: ${job.id})`);

      switch (job.name) {
        case 'GENERATE_INVOICE_PDF':
          await handleGenerateInvoicePdf(job.data.orderId, job.data.customerEmail, job.data.customerName);
          break;
        case 'SEND_NOTIFICATION':
          await handleSendNotification(job.data);
          break;
        case 'CREDIT_REFERRAL_POINTS':
          await handleCreditReferralPoints(job.data.orderId, job.data.userId);
          break;
        default:
          logger.warn(`Unknown job name: ${job.name}`);
      }
    },
    {
      connection: connectionOptions,
      concurrency: 2,
      drainDelay: 30, // Wait 30 seconds between polls when queue is empty (saves Redis commands)
    }
  );

  worker.on('error', (err) => {
    if (err.message && (err.message.includes('ECONNRESET') || err.message.includes('closed'))) {
      logger.warn('BullMQ Worker: Redis connection reset, reconnecting...');
      return;
    }
    logger.error('BullMQ Worker Error:', { metadata: { error: err.message } });
  });

  // Failure listener for DLQ handling
  worker.on('failed', async (job, err) => {
    if (!job) return;
    
    logger.error(`JOB_FAILURE: Job ${job.name} (ID: ${job.id}) failed after ${job.attemptsMade} retries`, {
      metadata: { error: err.message, stack: err.stack, data: job.data },
    });

    try {
      // 1. Write to database AuditLog
      await prisma.auditLog.create({
        data: {
          action: 'JOB_FAILURE',
          details: {
            message: `Background job ${job.name} (ID: ${job.id}) failed permanently.`,
            error: err.message,
            stack: err.stack,
            jobData: job.data,
            attemptsMade: job.attemptsMade,
          },
        },
      });

      // 2. Broadcast socket audit:alert to superadmins
      const io = getIO();
      if (io) {
        io.to('superadmins').emit('audit:alert', {
          action: 'JOB_FAILURE',
          jobName: job.name,
          jobId: job.id,
          message: `Job ${job.name} failed: ${err.message}`,
        });
      }

      // 3. Log invoice generation failure — DO NOT cancel the order
      // The order is already paid/valid; PDF failure is a non-critical side effect
      if (job.name === 'GENERATE_INVOICE_PDF' && job.data.orderId) {
        logger.error(`Invoice PDF generation failed for order ${job.data.orderId}. Order status NOT changed. Admin intervention required.`);
        // Notify superadmins specifically about the invoice failure
        const io2 = getIO();
        if (io2) {
          io2.to('superadmins').emit('audit:alert', {
            action: 'INVOICE_PDF_FAILED',
            orderId: job.data.orderId,
            message: `Invoice PDF generation permanently failed for order ${job.data.orderId}. Manual generation required.`,
          });
        }
      }
    } catch (e: any) {
      logger.error('Failed to execute job failure cleanup rules', { metadata: { error: e.message } });
    }
  });

  logger.info('BullMQ Background Worker Initialized.');
}

/**
 * PDF generator background handler
 */
export async function handleGenerateInvoicePdf(orderId: string, customerEmail?: string, customerName?: string) {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: {
      orderItems: {
        include: { product: true },
      },
      user: true,
    },
  });

  if (!order) {
    throw new Error(`Order ${orderId} not found`);
  }

  // Resolve customer information from DB relation, parameters, or stored gatewayResponse
  const rawGuestEmail = (order.gatewayResponse as any)?.guestCustomerEmail;
  const rawGuestName = (order.gatewayResponse as any)?.guestCustomerName;
  const rawGuestPhone = (order.gatewayResponse as any)?.guestCustomerPhone;

  const resolvedEmail = order.user?.email || customerEmail || rawGuestEmail || '';
  const resolvedName = order.user?.fullName || customerName || rawGuestName || 'Valued Customer';
  const resolvedPhone = order.user?.phoneNumber || rawGuestPhone || 'N/A';

  const customer = {
    id: order.user?.id || '',
    fullName: resolvedName,
    email: resolvedEmail || 'guest@marcosapp.com',
    phoneNumber: resolvedPhone,
  };

  // Compile PDF via PDFKit service
  const pdfBuffer = await PdfService.generateInvoicePdf(order, customer);

  // Upload to object store (Cloudflare R2 or local fallback)
  const fileKey = `invoices/${order.invoiceNumber}-${Date.now()}.pdf`;
  const pdfUrl = await R2Service.uploadFile(pdfBuffer, fileKey, 'application/pdf');

  // Save/Update Invoice model
  const invoice = await prisma.invoice.upsert({
    where: { orderId: order.id },
    update: { pdfUrl },
    create: {
      orderId: order.id,
      pdfUrl,
    },
  });

  // Log INVOICE_GENERATED
  await prisma.auditLog.create({
    data: {
      userId: order.userId || null,
      action: 'INVOICE_GENERATED',
      details: {
        message: `PDF Invoice generated and uploaded for Order ${order.invoiceNumber}. PDF URL: ${pdfUrl}`,
        orderId: order.id,
        invoiceId: invoice.id,
        pdfUrl,
      },
    },
  }).catch((err: any) => logger.error('Failed to log invoice generation audit:', err));

  // Trigger notification send job downstream to the customer
  if (resolvedEmail && resolvedEmail !== 'guest@marcosapp.com') {
    await JobsProducer.queueNotification({
      userId: order.userId || '',
      email: resolvedEmail,
      phone: resolvedPhone,
      channels: ['EMAIL'],
      templates: {
        email: {
          id: 'invoice-template',
          data: {
            customerName: resolvedName,
            invoiceNumber: order.invoiceNumber,
            payableAmount: order.payableAmount,
            invoiceUrl: pdfUrl,
          },
        },
      },
    });
  }
}

/**
 * Notification dispatcher background handler
 */
export async function handleSendNotification(data: any) {
  const { userId, email, phone, channels, templates } = data;
  
  let user: any = null;
  if (userId) {
    user = await prisma.user.findUnique({ where: { id: userId } });
  }

  const recipientEmail = email || user?.email || 'customer@example.com';
  const recipientPhone = phone || user?.phoneNumber || '+1234567890';

  for (const channel of channels) {
    if (channel === 'EMAIL' && templates.email) {
      const invoiceUrl = templates.email.data?.invoiceUrl;
      const invoiceNumber = templates.email.data?.invoiceNumber;
      const attachments = invoiceUrl
        ? [{ filename: `invoice-${invoiceNumber || 'details'}.pdf`, path: invoiceUrl }]
        : undefined;

      await EmailService.sendEmail(
        recipientEmail,
        `Your Invoice ${invoiceNumber || ''}`,
        `Hello ${templates.email.data?.customerName || 'Customer'}, here is your invoice.`,
        undefined,
        templates.email.id,
        templates.email.data,
        attachments
      );
    }
    
    if (channel === 'SMS' && templates.sms) {
      await SmsService.sendSms(recipientPhone, templates.sms);
    }
    
    if (channel === 'PUSH' && templates.push && userId) {
      // 1. Persist notification in database first
      const notification = await prisma.notification.create({
        data: {
          title: templates.push.title,
          body: templates.push.body,
          type: 'ORDER_UPDATE',
        },
      });

      await prisma.notificationRecipient.create({
        data: {
          notificationId: notification.id,
          userId,
        },
      });

      // 2. Dispatch Push notification
      await NotificationService.sendPushNotification(
        userId,
        templates.push.title,
        templates.push.body
      );

      // 3. Emit real-time visit or order notification to the specific room
      const io = getIO();
      if (io) {
        io.to(`user:${userId}`).emit('notification:received', {
          id: notification.id,
          title: templates.push.title,
          body: templates.push.body,
        });
      }
    }
  }
}

/**
 * Referral points calculation background handler
 */
export async function handleCreditReferralPoints(orderId: string, userId: string) {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
  });

  if (!order) {
    throw new Error(`Order ${orderId} not found`);
  }

  // Calculate points: 1 point per $10 spent
  const spentAmount = Number(order.payableAmount);
  const earnedPoints = Math.floor(spentAmount / 10);

  // We run everything in a transaction to prevent concurrency bugs
  await prisma.$transaction(async (tx: any) => {
    // 1. Credit loyalty points for the purchase
    if (earnedPoints > 0) {
      await tx.user.update({
        where: { id: userId },
        data: {
          pointsBalance: { increment: earnedPoints },
        },
      });

      await tx.pointTransaction.create({
        data: {
          userId,
          points: earnedPoints,
          reason: `Purchase points for Order ${order.invoiceNumber}`,
        },
      });

      // Log POINTS_CREDITED
      await tx.auditLog.create({
        data: {
          userId: null,
          action: 'POINTS_CREDITED',
          details: {
            message: `Automatically credited ${earnedPoints} points to customer ID ${userId} for Order ${order.invoiceNumber}`,
            userId,
            points: earnedPoints,
            orderId: order.id,
            reason: 'purchase',
          },
        },
      });
    }

    // 2. Referral points: check if it's the customer's first completed/paid order
    const completedOrdersCount = await tx.order.count({
      where: {
        userId,
        status: { in: ['PAID', 'PROCESSING', 'SHIPPED', 'DELIVERED'] },
      },
    });

    // If this is their first order, check if they were referred by someone
    if (completedOrdersCount <= 1) {
      const user = await tx.user.findUnique({
        where: { id: userId },
      });

      if (user && user.referredById) {
        const referralBonus = 100; // 100 bonus points each

        // Credit referrer
        await tx.user.update({
          where: { id: user.referredById },
          data: {
            pointsBalance: { increment: referralBonus },
          },
        });

        await tx.pointTransaction.create({
          data: {
            userId: user.referredById,
            points: referralBonus,
            reason: `Referral bonus for referring user ${user.fullName}`,
          },
        });

        // Log REFERRAL_POINTS_AWARDED for referrer
        await tx.auditLog.create({
          data: {
            userId: null,
            action: 'REFERRAL_POINTS_AWARDED',
            details: {
              message: `Awarded ${referralBonus} referral points to referrer ID ${user.referredById} for user ID ${userId}'s first order`,
              userId: user.referredById,
              points: referralBonus,
              refereeUserId: userId,
              orderId,
            },
          },
        });

        // Credit referee — Note: referee already received 100 sign-up bonus during registration,
        // so we only credit the referrer here to avoid double-counting.
        // The referee's registration bonus was handled in auth.controller.ts
      }
    }
  });
}
